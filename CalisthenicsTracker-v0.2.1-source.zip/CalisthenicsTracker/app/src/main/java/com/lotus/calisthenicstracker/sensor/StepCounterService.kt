package com.lotus.calisthenicstracker.sensor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.lotus.calisthenicstracker.R
import com.lotus.calisthenicstracker.data.database.AppDatabase
import com.lotus.calisthenicstracker.data.repository.StepRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

class StepCounterService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var stepCounter: StepCounter

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()

        val notification = buildNotification()

        startForeground(
            NOTIFICATION_ID,
            notification
        )

        val dao = AppDatabase.get(applicationContext).stepDao()
        val repository = StepRepository(dao)

        stepCounter = StepCounter(applicationContext) { sensorTotal ->
            serviceScope.launch {
                saveSteps(repository, sensorTotal)
            }
        }

        stepCounter.start()
    }

    private suspend fun saveSteps(
        repository: StepRepository,
        sensorTotal: Long
    ) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val today = LocalDate.now()
        val dayStart = today
            .atStartOfDay(ZoneId.systemDefault())
            .toInstant()
            .toEpochMilli()

        val storedDay = prefs.getLong(KEY_DAY, Long.MIN_VALUE)
        var baseline = prefs.getLong(KEY_BASELINE, -1L)

        if (storedDay != dayStart) {
            baseline = sensorTotal
            prefs.edit()
                .putLong(KEY_DAY, dayStart)
                .putLong(KEY_BASELINE, baseline)
                .apply()
        }

        if (baseline < 0L || sensorTotal < baseline) {
            baseline = sensorTotal
            prefs.edit()
                .putLong(KEY_DAY, dayStart)
                .putLong(KEY_BASELINE, baseline)
                .apply()
        }

        val todaySteps = sensorTotal - baseline

        if (todaySteps >= 0L) {
            repository.save(dayStart, todaySteps)
        }
    }

    override fun onDestroy() {
        if (::stepCounter.isInitialized) {
            stepCounter.stop()
        }

        serviceScope.coroutineContext.cancel()

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val manager =
            getSystemService(NotificationManager::class.java)

        val channel = NotificationChannel(
            CHANNEL_ID,
            "Step tracking",
            NotificationManager.IMPORTANCE_LOW
        )

        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Calisthenics Tracker")
            .setContentText("Step tracking is active")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "step_tracking"
        private const val NOTIFICATION_ID = 1001
        private const val PREFS_NAME = "step_counter"
        private const val KEY_DAY = "day_start"
        private const val KEY_BASELINE = "sensor_baseline"
    }
}

# Build and install Calisthenics Tracker using your phone

The Android APK is built by GitHub Actions on a cloud build machine. You do not need Android Studio or a coding app on your phone.

## One-time setup

1. Open your GitHub repository in your phone browser.
2. Upload the **contents** of this project folder to the repository root. The root must contain `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/workflows/build-apk.yml`.
3. Commit the upload to the `main` branch. This starts the build workflow automatically.

## Build or rebuild

1. Open the repository's **Actions** tab.
2. Select **Build Android APK**.
3. Open the newest run and wait for it to finish. A green check means the build succeeded; a red X means it failed and its log must be inspected.
4. In a successful run, open **Artifacts** and download `CalisthenicsTracker-debug-apk`.
5. Extract the downloaded ZIP and install the `.apk` on your Android phone. Android may ask you to allow your browser or file manager to install apps from that source.

The workflow installs JDK 17, Android SDK platform 36/build tools, accepts SDK licences, and uses Gradle 8.13. This is a debug build for personal testing, not a Play Store release.

package com.lotus.calisthenicstracker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lotus.calisthenicstracker.domain.rank.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember

private data class RankInfo(val title: String, val description: String, val tier: String? = null)
private val subRanks = listOf(
    "Initiate" to "Entry stage: learn the movement standard and train safely.",
    "Adept" to "Build repeatable performance with controlled technique.",
    "Master" to "Demonstrate consistency across multiple sessions.",
    "Ascendant" to "Complete the tier target before advancing to the next main rank."
)

@Composable
fun MainScreen() {
    var selected by remember { mutableIntStateOf(0) }
    var activeExercise by remember { mutableStateOf<Exercise?>(null) }
    val workoutViewModel: WorkoutViewModel = androidx.lifecycle.viewmodel.compose.viewModel()

    if (activeExercise != null) {
        CameraWorkoutScreen(exercise = activeExercise!!, viewModel = workoutViewModel, onBack = { activeExercise = null })
        return
    }

    val tabs = listOf("Home", "Workout", "Ranks", "Progress", "Profile")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, title ->
                NavigationBarItem(selected = selected == i, onClick = { selected = i }, icon = {}, label = { Text(title) })
            }
        }
    }) { pad ->
        when (selected) {
            0 -> HomeScreen(Modifier.padding(pad))
            1 -> WorkoutScreen(Modifier.padding(pad)) { exercise -> workoutViewModel.selectExercise(exercise); activeExercise = exercise }
            2 -> RanksScreen(Modifier.padding(pad))
            3 -> ProgressScreen(Modifier.padding(pad))
            else -> ProfileScreen(Modifier.padding(pad))
        }
    }
}

@Composable
private fun HomeScreen(m: Modifier) = Column(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Text("Calisthenics Rank System", style = MaterialTheme.typography.headlineMedium)
    Text("Train. Verify. Ascend.", style = MaterialTheme.typography.titleMedium)
    RankCard("Rep Rank", "Ashen Initiate", "30 main ranks · 4 sub-ranks each")
    RankCard("Skill Rank", "Ashen Initiate", "A separate 30-rank path for calisthenics skills")
    Text("Tap any rank or sub-rank in the Ranks tab to read its lore and advancement guidance.")
}

@Composable
private fun RankCard(title: String, value: String, note: String) = Card(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) { Text(title); Text(value, style = MaterialTheme.typography.headlineSmall); Text(note) }
}

@Composable
private fun WorkoutScreen(m: Modifier, onStart: (Exercise) -> Unit) = Column(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Workout", style = MaterialTheme.typography.headlineMedium)
    listOf(Exercise.PUSH_UP, Exercise.PULL_UP, Exercise.SQUAT, Exercise.DIP).forEach { exercise ->
        Card(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(exerciseLabel(exercise))
                Button(onClick = { onStart(exercise) }) { Text("Start") }
            }
        }
    }
}

@Composable
private fun RanksScreen(m: Modifier) {
    var info by remember { mutableStateOf<RankInfo?>(null) }
    var path by remember { mutableStateOf("Rep Rank") }
    Column(m.padding(12.dp)) {
        Text("Martial Realm Rankings", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = path == "Rep Rank", onClick = { path = "Rep Rank" }, label = { Text("Rep Rank · 30") })
            FilterChip(selected = path == "Skill Rank", onClick = { path = "Skill Rank" }, label = { Text("Skill Rank · 30") })
        }
        Text("Tap a main rank or one of its four sub-ranks for details.", style = MaterialTheme.typography.bodyMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            val ranks = if (path == "Rep Rank") RepRank.entries.map { Triple(it.label, it.description, it.ordinal) } else SkillRank.entries.map { Triple(it.label, it.description, it.ordinal) }
            items(ranks) { (label, description, index) ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${index + 1}. $label", style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.fillMaxWidth().clickable { info = RankInfo(label, description) }.padding(vertical = 5.dp))
                        Text(if (path == "Rep Rank") repRequirementSummary(index) else "Skill path: complete progressive holds, balance, strength, and control challenges.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(5.dp))
                        subRanks.forEachIndexed { tierIndex, pair ->
                            Text("${tierIndex + 1}. ${pair.first}  ›", color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    info = RankInfo("$label — ${pair.first}", pair.second + if (path == "Rep Rank") " Rep targets at this main rank: ${repRequirementSummary(index)}" else " Skill challenges should be completed with controlled form and appropriate spotting/support.", pair.first)
                                }.padding(vertical = 5.dp))
                        }
                    }
                }
            }
        }
    }
    info?.let { selected ->
        AlertDialog(onDismissRequest = { info = null },
            title = { Text(selected.title) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(selected.description)
                if (selected.tier != null) Text("Sub-rank: ${selected.tier}")
                Text("This is a gamified progression guide, not a guarantee of ability. Use clean form, rest, and safe progressions.")
            } },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Close") } })
    }
}

private fun repRequirementSummary(index: Int): String {
    val rank = RepRank.entries[index]
    return "Target PRs: ${RepRequirements.minimum(Exercise.PUSH_UP, rank)} push-ups · ${RepRequirements.minimum(Exercise.PULL_UP, rank)} pull-ups · ${RepRequirements.minimum(Exercise.SQUAT, rank)} squats · ${RepRequirements.minimum(Exercise.DIP, rank)} dips"
}

@Composable
private fun ProgressScreen(m: Modifier) {
    val vm: WorkoutViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val workouts by vm.history.collectAsState(initial = emptyList())
    Column(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Progress", style = MaterialTheme.typography.headlineMedium)
        Text("Saved workouts: ${workouts.size}")
        if (workouts.isEmpty()) Text("Complete a camera workout to start your history.")
        workouts.take(20).forEach { workout ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text("${workout.totalReps} verified reps")
                Text("Started: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(workout.startedAt))}")
            } }
        }
    }
}

@Composable
private fun ProfileScreen(m: Modifier) = Column(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Profile", style = MaterialTheme.typography.headlineMedium)
    Text("Permission: Camera")
    Text("Minimum Android version: Android 10 (API 29)")
}

private fun exerciseLabel(exercise: Exercise) = when (exercise) {
    Exercise.PUSH_UP -> "Push-ups"
    Exercise.PULL_UP -> "Pull-ups"
    Exercise.SQUAT -> "Squats"
    Exercise.DIP -> "Dips"
}

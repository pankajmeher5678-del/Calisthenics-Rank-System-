package com.lotus.calisthenicstracker.domain.rank

enum class SkillRank(val label: String, val description: String) {
    WOOD("Ashen Initiate", "The first spark of discipline. Build consistent movement and learn strict form."),
    BRONZE("Ironbound Disciple", "Your foundation hardens through repeatable, controlled training."),
    SILVER("Ember Fist", "The first inner flame: basic strength becomes dependable."),
    GOLD("Jade Vanguard", "Balance control, stamina, and clean technique."),
    PLATINUM("Stormfoot Adept", "Move with precision while maintaining steady output."),
    DIAMOND("Moonblade Guardian", "A strong base supports demanding bodyweight work."),
    CHAMPION("Crimson Crane", "Control and endurance begin to work together."),
    TITAN("Obsidian Sentinel", "A resilient practitioner with disciplined technique."),
    OLYMPIAN("Azure Dragon", "A high-level foundation across the core movements."),
    RANK_10("Thunder Gate Keeper", "Pass the first great gate with consistency and control."),
    RANK_11("Silver Phoenix", "Strength returns stronger through patient practice."),
    RANK_12("Voidstep Warrior", "Efficient movement and precise body awareness."),
    RANK_13("Sapphire Sword Saint", "Technique remains sharp even as demands rise."),
    RANK_14("Celestial Tiger", "Power and composure under challenging workloads."),
    RANK_15("Frost Lotus Master", "A calm, technically sound and well-rounded practitioner."),
    RANK_16("Thunder Sovereign", "Advanced strength supported by repeatable performance."),
    RANK_17("Astral Phoenix", "Exceptional consistency and refined movement quality."),
    RANK_18("Heavenly Iron Lord", "A formidable foundation across the main exercises."),
    RANK_19("Eclipse Warlord", "Strength, control, and stamina approach elite territory."),
    RANK_20("Dragon Vein Sage", "A rare level of bodyweight mastery and discipline."),
    RANK_21("Starforged Monarch", "Performance remains strong across demanding sessions."),
    RANK_22("Spirit Realm Champion", "A master of consistency, control, and progression."),
    RANK_23("Ninefold Ascendant", "Exceptional capacity across multiple movement patterns."),
    RANK_24("Heavenbreaker", "A legendary tier requiring years of measured practice."),
    RANK_25("Eternal Flame Sovereign", "Strength and technique are maintained at an extraordinary level."),
    RANK_26("World Serpent Emperor", "A near-mythic standard of bodyweight performance."),
    RANK_27("Celestial Realm Overlord", "Elite capacity paired with disciplined execution."),
    RANK_28("Primordial Dragon King", "A legendary practitioner with remarkable all-round ability."),
    RANK_29("Cosmic Martial Saint", "Near the summit of the complete rank ladder."),
    RANK_30("Transcendent Immortal", "The highest title in this fictional progression system.")
}

data class SkillProgress(
    val skill: String,
    val stage: String,
    val rank: SkillRank,
    val verified: Boolean
)

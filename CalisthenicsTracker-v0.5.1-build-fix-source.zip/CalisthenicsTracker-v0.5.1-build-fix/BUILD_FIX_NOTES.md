# Calisthenics Tracker v0.5.1 build-fix package

This package carries the v0.5.0 ROM/source project plus a corrected GitHub Actions workflow intended to resolve the previous `Android project was not found` failure.

## What changed
- Replaced `.github/workflows/build-apk.yml` with a workflow that extracts the source archive, searches recursively for `settings.gradle.kts`, verifies `app/build.gradle.kts`, and prints diagnostic file listings if the project root cannot be located.
- Preserves release signing via the existing GitHub Actions secrets. If those secrets are incomplete, it builds a debug APK instead.
- Uploads the resulting APK as a GitHub Actions artifact.

## Important
This is a source/build-fix ZIP, not an APK. A successful GitHub Actions run is still required to produce the installable APK. The build has not been run from this package in this environment.

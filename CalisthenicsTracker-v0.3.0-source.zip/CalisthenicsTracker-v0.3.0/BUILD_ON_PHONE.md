# Build the APK using only your phone

This project is prepared for GitHub Actions. You do not need Android Studio on your phone.

## 1. Create a GitHub repository

Create an empty repository on GitHub from your phone.

## 2. Upload this project

Extract this ZIP on your phone and upload the **contents of the `CalisthenicsTracker` folder** to the repository. The repository root must contain:

- `settings.gradle.kts`
- `build.gradle.kts`
- `app/`
- `.github/workflows/build-apk.yml`

Do not upload the outer `CalisthenicsTracker` directory as an additional nesting level.

## 3. Start the build

Open the repository on GitHub → **Actions** → **Build Android APK** → **Run workflow**.

The workflow installs JDK 17 and Gradle 8.13 on GitHub's build machine and runs:

`gradle --no-daemon :app:assembleDebug`

## 4. Download the APK

After the workflow finishes successfully:

Actions → the completed run → **Artifacts** → `CalisthenicsTracker-debug-apk`.

Download the ZIP artifact to your phone, extract it, and install the `.apk`.

## Important

This is a debug APK. It is suitable for installing/testing on your own Android device. A Play Store release would require a signed release build and additional release configuration.

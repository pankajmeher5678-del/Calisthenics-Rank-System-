package com.lotus.calisthenicstracker.domain.rank

enum class Exercise { PUSH_UP, PULL_UP, SQUAT, DIP }

enum class RepRank(val label: String) {
    WOOD("Wood"), BRONZE("Bronze"), SILVER("Silver"), GOLD("Gold"),
    PLATINUM("Platinum"), DIAMOND("Diamond"), CHAMPION("Champion"), TITAN("Titan"), OLYMPIAN("Olympian")
}

/** Exercise-specific thresholds. A rank is PR-based, not today's fatigue-based performance. */
object RepRequirements {
    private val pushUps = intArrayOf(0,15,30,45,60,75,90,105,120)
    private val pullUps = intArrayOf(0,1,6,11,16,21,26,31,36)
    private val squats = intArrayOf(0,30,60,90,120,150,180,210,240)

    fun minimum(exercise: Exercise, rank: RepRank): Int = when (exercise) {
        Exercise.PUSH_UP -> pushUps[rank.ordinal]
        Exercise.PULL_UP -> pullUps[rank.ordinal]
        Exercise.SQUAT -> squats[rank.ordinal]
        Exercise.DIP -> 0 // Dips are tracked now; their separate threshold table is intentionally configurable.
    }
}

data class RepTotals(val pushUps: Int = 0, val pullUps: Int = 0, val squats: Int = 0)

object RepRankCalculator {
    fun rankForExercise(exercise: Exercise, reps: Int): RepRank =
        RepRank.entries.lastOrNull { reps >= RepRequirements.minimum(exercise, it) } ?: RepRank.WOOD

    /** Overall rank cannot exceed the weakest of the three core rep exercises. */
    fun overall(t: RepTotals): RepRank = RepRank.entries.lastOrNull { rank ->
        t.pushUps >= RepRequirements.minimum(Exercise.PUSH_UP, rank) &&
        t.pullUps >= RepRequirements.minimum(Exercise.PULL_UP, rank) &&
        t.squats >= RepRequirements.minimum(Exercise.SQUAT, rank)
    } ?: RepRank.WOOD
}

package com.lotus.calisthenicstracker.domain.detection

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

data class Point2D(val x: Float, val y: Float, val confidence: Float = 1f)

object PoseMath {
    fun distance(a: Point2D, b: Point2D): Float = sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y))
    fun angle(a: Point2D, b: Point2D, c: Point2D): Float {
        val abx=a.x-b.x; val aby=a.y-b.y; val cbx=c.x-b.x; val cby=c.y-b.y
        val dot=abx*cbx+aby*cby
        val denom=sqrt(abx*abx+aby*aby)*sqrt(cbx*cbx+cby*cby)
        if (denom <= 0f) return 180f
        return Math.toDegrees(acos((dot/denom).coerceIn(-1f,1f)).toDouble()).toFloat()
    }
    fun confident(vararg points: Point2D, min: Float = .65f): Boolean = points.all { it.confidence >= min }
    fun near(a: Float, b: Float, tolerance: Float): Boolean = abs(a-b) <= tolerance
}

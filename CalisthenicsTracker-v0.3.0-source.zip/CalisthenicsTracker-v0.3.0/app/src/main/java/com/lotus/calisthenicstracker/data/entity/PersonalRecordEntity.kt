package com.lotus.calisthenicstracker.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "personal_records")
data class PersonalRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val exercise: String,
    val reps: Int,
    val achievedAt: Long,
    val verificationMethod: String
)

package com.lotus.calisthenicstracker.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.lotus.calisthenicstracker.camera.PoseAnalyzer
import com.lotus.calisthenicstracker.domain.detection.*
import com.lotus.calisthenicstracker.domain.rank.Exercise
import com.lotus.calisthenicstracker.domain.workout.RepValidator
import java.util.concurrent.Executors

@Composable
fun CameraWorkoutScreen(
    exercise: Exercise,
    viewModel: WorkoutViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val reps by viewModel.reps.collectAsState()
    val phase by viewModel.phase.collectAsState()
    val status by viewModel.lastStatus.collectAsState()

    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(exerciseLabel(exercise), style = MaterialTheme.typography.titleLarge)
            Text("$reps reps", style = MaterialTheme.typography.titleLarge)
        }
        if (granted) {
            CameraPreview(exercise, viewModel, lifecycleOwner, Modifier.fillMaxWidth().weight(1f))
            Text("Phase: ${phase.name}")
            Text(if (status.name == "VALID") "Valid rep accepted" else "Move through the full range of motion")
        } else {
            Text("Camera permission is required for automatic counting.")
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Allow Camera") }
            Text("You can keep manual counting available in the full workout flow.")
        }
        OutlinedButton(onClick = { viewModel.finishWorkout(); onBack() }, modifier = Modifier.fillMaxWidth()) { Text("Finish & Save") }
    }
}

@Composable
private fun CameraPreview(
    exercise: Exercise,
    viewModel: WorkoutViewModel,
    lifecycleOwner: androidx.lifecycle.LifecycleOwner,
    modifier: Modifier
) {
    val context = LocalContext.current
    val previewView = remember(context) {
        PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }

    DisposableEffect(exercise, lifecycleOwner) {
        val executor = Executors.newSingleThreadExecutor()
        val future = ProcessCameraProvider.getInstance(context)
        var analyzer: PoseAnalyzer? = null
        val providerListener = Runnable {
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analyzer = PoseAnalyzer(
                detector = detectorFor(exercise),
                validator = RepValidator(exercise),
                onPhase = viewModel::onPhase,
                onRep = viewModel::onRep
            )
            analysis.setAnalyzer(executor, analyzer!!)
            provider.unbindAll()
            provider.bindToLifecycle(
                lifecycleOwner,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                analysis
            )
        }
        future.addListener(providerListener, ContextCompat.getMainExecutor(context))

        onDispose {
            if (future.isDone) {
                runCatching { future.get().unbindAll() }
            }
            analyzer?.close()
            executor.shutdownNow()
        }
    }

    AndroidView(factory = { previewView }, modifier = modifier)
}

private fun detectorFor(exercise: Exercise): ExerciseDetector = when (exercise) {
    Exercise.PUSH_UP -> PushUpDetector()
    Exercise.PULL_UP -> PullUpDetector()
    Exercise.SQUAT -> SquatDetector()
    Exercise.DIP -> DipDetector()
}

private fun exerciseLabel(exercise: Exercise) = when (exercise) {
    Exercise.PUSH_UP -> "Push-ups"
    Exercise.PULL_UP -> "Pull-ups"
    Exercise.SQUAT -> "Squats"
    Exercise.DIP -> "Dips"
}

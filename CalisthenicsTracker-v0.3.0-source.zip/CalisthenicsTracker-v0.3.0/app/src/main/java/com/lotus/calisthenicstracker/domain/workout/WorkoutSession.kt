package com.lotus.calisthenicstracker.domain.workout

import com.lotus.calisthenicstracker.domain.rank.Exercise

class WorkoutSession {
    private val reps = linkedMapOf<Exercise, Int>()
    private var startedAt: Long = 0
    fun start(now: Long = System.currentTimeMillis()) { startedAt = now; reps.clear() }
    fun addValidRep(exercise: Exercise) { reps[exercise] = (reps[exercise] ?: 0) + 1 }
    fun repsFor(exercise: Exercise): Int = reps[exercise] ?: 0
    fun totalReps(): Int = reps.values.sum()
    fun startedAt(): Long = startedAt
    fun snapshot(): Map<Exercise, Int> = reps.toMap()
}

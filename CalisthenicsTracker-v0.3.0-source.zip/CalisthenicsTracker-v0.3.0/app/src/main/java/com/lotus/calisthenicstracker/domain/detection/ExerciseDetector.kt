package com.lotus.calisthenicstracker.domain.detection

import com.lotus.calisthenicstracker.domain.workout.MovementPhase

interface ExerciseDetector {
    fun phase(points: Map<String, Point2D>): MovementPhase
}

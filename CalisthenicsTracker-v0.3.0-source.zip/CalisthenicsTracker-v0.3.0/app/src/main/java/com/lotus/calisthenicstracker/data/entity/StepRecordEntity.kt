package com.lotus.calisthenicstracker.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "step_records")
data class StepRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayStart: Long,
    val steps: Long
)

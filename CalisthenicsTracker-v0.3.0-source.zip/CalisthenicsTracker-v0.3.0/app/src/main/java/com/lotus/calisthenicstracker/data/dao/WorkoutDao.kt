package com.lotus.calisthenicstracker.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.lotus.calisthenicstracker.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkoutDao {
    @Insert suspend fun insertWorkout(workout: WorkoutEntity): Long
    @Insert suspend fun insertSet(set: SetEntity): Long
    @Insert suspend fun insertPr(pr: PersonalRecordEntity): Long
    @Query("SELECT * FROM workouts ORDER BY startedAt DESC") fun observeWorkouts(): Flow<List<WorkoutEntity>>
    @Query("SELECT MAX(reps) FROM personal_records WHERE exercise = :exercise") fun observePr(exercise: String): Flow<Int?>
    @Query("SELECT MAX(reps) FROM personal_records WHERE exercise = :exercise") suspend fun maxPr(exercise: String): Int?
}

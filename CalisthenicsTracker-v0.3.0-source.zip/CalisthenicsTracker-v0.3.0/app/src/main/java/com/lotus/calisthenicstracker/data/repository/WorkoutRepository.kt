package com.lotus.calisthenicstracker.data.repository

import com.lotus.calisthenicstracker.data.dao.WorkoutDao
import com.lotus.calisthenicstracker.data.entity.PersonalRecordEntity
import com.lotus.calisthenicstracker.data.entity.SetEntity
import com.lotus.calisthenicstracker.data.entity.WorkoutEntity
import com.lotus.calisthenicstracker.domain.rank.Exercise
import kotlinx.coroutines.flow.Flow

class WorkoutRepository(private val dao: WorkoutDao) {
    fun observeWorkouts(): Flow<List<WorkoutEntity>> = dao.observeWorkouts()
    fun observePr(exercise: Exercise): Flow<Int?> = dao.observePr(exercise.name)
    suspend fun maxPr(exercise: Exercise): Int? = dao.maxPr(exercise.name)
    suspend fun saveWorkout(startedAt: Long, endedAt: Long, totals: Map<Exercise, Int>) {
        val total = totals.values.sum()
        val workoutId = dao.insertWorkout(
            WorkoutEntity(startedAt = startedAt, endedAt = endedAt, totalReps = total, verifiedReps = total)
        )
        totals.forEach { (exercise, reps) ->
            if (reps <= 0) return@forEach
            dao.insertSet(SetEntity(workoutId = workoutId, exercise = exercise.name, reps = reps, validReps = reps, detectionMethod = "camera"))
        }
    }

    suspend fun savePr(exercise: Exercise, reps: Int, achievedAt: Long) {
        dao.insertPr(PersonalRecordEntity(exercise = exercise.name, reps = reps, achievedAt = achievedAt, verificationMethod = "camera"))
    }
}

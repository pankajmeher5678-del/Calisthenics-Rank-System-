package com.lotus.calisthenicstracker.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.lotus.calisthenicstracker.data.dao.NotificationSettingsDao
import com.lotus.calisthenicstracker.data.dao.StepDao
import com.lotus.calisthenicstracker.data.dao.UserProfileDao
import com.lotus.calisthenicstracker.data.dao.WorkoutDao
import com.lotus.calisthenicstracker.data.entity.NotificationSettingsEntity
import com.lotus.calisthenicstracker.data.entity.PersonalRecordEntity
import com.lotus.calisthenicstracker.data.entity.SetEntity
import com.lotus.calisthenicstracker.data.entity.StepRecordEntity
import com.lotus.calisthenicstracker.data.entity.UserProfileEntity
import com.lotus.calisthenicstracker.data.entity.WorkoutEntity

@Database(
    entities = [
        WorkoutEntity::class,
        SetEntity::class,
        PersonalRecordEntity::class,
        StepRecordEntity::class,
        UserProfileEntity::class,
        NotificationSettingsEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun workoutDao(): WorkoutDao
    abstract fun stepDao(): StepDao
    abstract fun userProfileDao(): UserProfileDao
    abstract fun notificationSettingsDao(): NotificationSettingsDao

    companion object {

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {

                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS user_profile (
                        id INTEGER NOT NULL,
                        userId TEXT NOT NULL,
                        displayName TEXT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        PRIMARY KEY(id)
                    )
                    """.trimIndent()
                )

                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS notification_settings (
                        id INTEGER NOT NULL,
                        stepNotificationEnabled INTEGER NOT NULL,
                        goalNotificationEnabled INTEGER NOT NULL,
                        dailyStepGoal INTEGER NOT NULL,
                        PRIMARY KEY(id)
                    )
                    """.trimIndent()
                )
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "calisthenics_tracker.db"
                )
                    .addMigrations(MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
    }
}

package com.lotus.calisthenicstracker.domain.workout

import com.lotus.calisthenicstracker.domain.rank.Exercise

enum class MovementPhase { TOP, DESCENDING, BOTTOM, ASCENDING, HANG, UNKNOWN }
enum class RepStatus { NONE, VALID, QUESTIONABLE }

/**
 * Exercise-aware state machine. A rep is accepted only after the complete
 * movement cycle has been observed; a cooldown prevents double-counting.
 */
class RepValidator(
    private val exercise: Exercise,
    private val cooldownFrames: Int = 8
) {
    private var phase = MovementPhase.UNKNOWN
    private var framesSinceRep = cooldownFrames
    private var pullUpReachedTop = false

    fun update(next: MovementPhase): RepStatus {
        framesSinceRep++
        if (next == MovementPhase.UNKNOWN) return RepStatus.NONE

        val completed = when (exercise) {
            Exercise.PULL_UP -> {
                if (next == MovementPhase.TOP) pullUpReachedTop = true
                pullUpReachedTop && next == MovementPhase.HANG
            }
            Exercise.PUSH_UP, Exercise.SQUAT, Exercise.DIP ->
                phase == MovementPhase.ASCENDING && next == MovementPhase.TOP
        }

        // For pull-ups, reaching the bottom/hang after a valid top completes the cycle.
        phase = next
        if (completed && framesSinceRep >= cooldownFrames) {
            framesSinceRep = 0
            return RepStatus.VALID
        }
        return RepStatus.NONE
    }

    fun reset() {
        phase = MovementPhase.UNKNOWN
        framesSinceRep = cooldownFrames
        pullUpReachedTop = false
    }
}

package com.lotus.calisthenicstracker.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.lotus.calisthenicstracker.data.entity.NotificationSettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationSettingsDao {

    @Query("SELECT * FROM notification_settings WHERE id = 1 LIMIT 1")
    fun observe(): Flow<NotificationSettingsEntity?>

    @Query("SELECT * FROM notification_settings WHERE id = 1 LIMIT 1")
    suspend fun get(): NotificationSettingsEntity?

    @Insert
    suspend fun insert(settings: NotificationSettingsEntity)

    @Update
    suspend fun update(settings: NotificationSettingsEntity)
}

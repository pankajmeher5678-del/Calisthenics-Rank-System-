package com.lotus.calisthenicstracker.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lotus.calisthenicstracker.data.database.AppDatabase
import com.lotus.calisthenicstracker.data.entity.UserProfileEntity
import com.lotus.calisthenicstracker.data.repository.UserProfileRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class UserProfileViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = UserProfileRepository(
        AppDatabase.get(application).userProfileDao()
    )

    val profile: StateFlow<UserProfileEntity?> =
        repository.observe().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            null
        )

    init {
        viewModelScope.launch {
            repository.getOrCreate()
        }
    }

    fun updateName(name: String) {
        val cleanName = name.trim()

        if (cleanName.isEmpty()) return

        viewModelScope.launch {
            repository.updateName(cleanName)
        }
    }
}

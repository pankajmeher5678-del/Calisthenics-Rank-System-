package com.lotus.calisthenicstracker.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lotus.calisthenicstracker.data.database.AppDatabase
import com.lotus.calisthenicstracker.data.repository.WorkoutRepository
import com.lotus.calisthenicstracker.domain.rank.Exercise
import com.lotus.calisthenicstracker.domain.workout.MovementPhase
import com.lotus.calisthenicstracker.domain.workout.RepStatus
import com.lotus.calisthenicstracker.domain.workout.WorkoutSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class WorkoutViewModel(application: Application) : AndroidViewModel(application) {
    private val session = WorkoutSession()
    private val repository = WorkoutRepository(AppDatabase.get(application).workoutDao())
    private val _selectedExercise = MutableStateFlow(Exercise.PUSH_UP)
    private val _reps = MutableStateFlow(0)
    private val _phase = MutableStateFlow(MovementPhase.UNKNOWN)
    private val _lastStatus = MutableStateFlow(RepStatus.NONE)
    private val _saved = MutableStateFlow(false)

    val selectedExercise = _selectedExercise.asStateFlow()
    val reps = _reps.asStateFlow()
    val phase = _phase.asStateFlow()
    val lastStatus = _lastStatus.asStateFlow()
    val saved = _saved.asStateFlow()
    val history = repository.observeWorkouts()

    init { session.start() }

    fun selectExercise(exercise: Exercise) {
        _selectedExercise.value = exercise
        _reps.value = 0
        _phase.value = MovementPhase.UNKNOWN
        _lastStatus.value = RepStatus.NONE
        _saved.value = false
        session.start()
    }

    fun onPhase(value: MovementPhase) { _phase.value = value }

    fun onRep(status: RepStatus) {
        _lastStatus.value = status
        if (status == RepStatus.VALID) {
            session.addValidRep(_selectedExercise.value)
            _reps.update { it + 1 }
        }
    }

    fun finishWorkout() {
        val totals = session.snapshot()
        if (totals.isEmpty()) return
        val started = session.startedAt()
        val ended = System.currentTimeMillis()
        viewModelScope.launch {
            repository.saveWorkout(started, ended, totals)
            totals.forEach { (exercise, count) ->
                val old = repository.maxPr(exercise)
                if (old == null || count > old) repository.savePr(exercise, count, ended)
            }
            _saved.value = true
        }
    }
}

package com.lotus.calisthenicstracker.domain.detection

import com.lotus.calisthenicstracker.domain.workout.MovementPhase

class PullUpDetector : ExerciseDetector {
    override fun phase(p: Map<String, Point2D>): MovementPhase {
        val shoulder=p["shoulder"]?:return MovementPhase.UNKNOWN
        val elbow=p["elbow"]?:return MovementPhase.UNKNOWN
        val wrist=p["wrist"]?:return MovementPhase.UNKNOWN
        if (!PoseMath.confident(shoulder,elbow,wrist)) return MovementPhase.UNKNOWN
        val a=PoseMath.angle(shoulder,elbow,wrist)
        return when { a>155f->MovementPhase.HANG; a<75f->MovementPhase.TOP; a<120f->MovementPhase.ASCENDING; else->MovementPhase.DESCENDING }
    }
}

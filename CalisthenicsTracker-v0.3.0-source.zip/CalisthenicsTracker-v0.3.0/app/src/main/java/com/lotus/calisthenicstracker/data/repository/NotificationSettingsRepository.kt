package com.lotus.calisthenicstracker.data.repository

import com.lotus.calisthenicstracker.data.dao.NotificationSettingsDao
import com.lotus.calisthenicstracker.data.entity.NotificationSettingsEntity
import kotlinx.coroutines.flow.Flow

class NotificationSettingsRepository(
    private val dao: NotificationSettingsDao
) {

    fun observe(): Flow<NotificationSettingsEntity?> = dao.observe()

    suspend fun getOrCreate(): NotificationSettingsEntity {
        val existing = dao.get()

        if (existing != null) {
            return existing
        }

        val settings = NotificationSettingsEntity()

        dao.insert(settings)

        return settings
    }

    suspend fun setStepNotificationEnabled(enabled: Boolean) {
        val settings = dao.get() ?: getOrCreate()

        dao.update(
            settings.copy(
                stepNotificationEnabled = enabled
            )
        )
    }

    suspend fun setGoalNotificationEnabled(enabled: Boolean) {
        val settings = dao.get() ?: getOrCreate()

        dao.update(
            settings.copy(
                goalNotificationEnabled = enabled
            )
        )
    }

    suspend fun setDailyStepGoal(goal: Int) {
        val settings = dao.get() ?: getOrCreate()

        dao.update(
            settings.copy(
                dailyStepGoal = goal.coerceAtLeast(0)
            )
        )
    }
}

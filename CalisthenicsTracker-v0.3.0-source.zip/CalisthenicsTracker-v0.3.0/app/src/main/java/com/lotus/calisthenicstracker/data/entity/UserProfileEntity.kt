package com.lotus.calisthenicstracker.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey
    val id: Int = 1,
    val userId: String,
    val displayName: String = "User",
    val createdAt: Long
)

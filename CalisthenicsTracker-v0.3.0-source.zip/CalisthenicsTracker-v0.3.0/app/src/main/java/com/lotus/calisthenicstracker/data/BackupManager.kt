package com.lotus.calisthenicstracker.data

import android.content.Context
import com.lotus.calisthenicstracker.data.database.AppDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.io.InputStream
import kotlinx.coroutines.flow.first

object BackupManager {
    suspend fun exportWorkouts(context: Context, output: OutputStream) {
        val workouts = AppDatabase.get(context).workoutDao().observeWorkouts()
        val latest = workouts.first()
        val root = JSONObject().put("schemaVersion", 1).put("workouts", JSONArray().apply {
            latest.forEach { put(JSONObject().put("startedAt", it.startedAt).put("endedAt", it.endedAt).put("totalReps", it.totalReps).put("verifiedReps", it.verifiedReps)) }
        })
        output.writer().use { it.write(root.toString(2)) }
    }

    // Restore intentionally validates schema before importing; database writes are added in the next release.
    fun validateBackup(input: InputStream): Boolean = try {
        val text = input.reader().use { it.readText() }
        JSONObject(text).optInt("schemaVersion", -1) == 1 && JSONObject(text).has("workouts")
    } catch (_: Exception) { false }
}

package com.lotus.calisthenicstracker.domain.detection

import com.lotus.calisthenicstracker.domain.workout.MovementPhase

class SquatDetector : ExerciseDetector {
    override fun phase(p: Map<String, Point2D>): MovementPhase {
        val hip = p["hip"] ?: return MovementPhase.UNKNOWN
        val knee = p["knee"] ?: return MovementPhase.UNKNOWN
        val ankle = p["ankle"] ?: return MovementPhase.UNKNOWN
        if (!PoseMath.confident(hip, knee, ankle)) return MovementPhase.UNKNOWN
        val kneeAngle = PoseMath.angle(hip, knee, ankle)
        return when {
            kneeAngle > 160f -> MovementPhase.TOP
            kneeAngle < 105f -> MovementPhase.BOTTOM
            kneeAngle < 140f -> MovementPhase.DESCENDING
            else -> MovementPhase.ASCENDING
        }
    }
}

package com.lotus.calisthenicstracker.data.repository

import com.lotus.calisthenicstracker.data.dao.StepDao
import com.lotus.calisthenicstracker.data.entity.StepRecordEntity
import kotlinx.coroutines.flow.Flow

class StepRepository(private val dao: StepDao) {
    fun observeHistory(): Flow<List<StepRecordEntity>> = dao.observeAll()
    suspend fun save(dayStart: Long, steps: Long) {
        if (dao.get(dayStart) == null) dao.insert(StepRecordEntity(dayStart = dayStart, steps = steps))
        else dao.update(dayStart, steps)
    }
}

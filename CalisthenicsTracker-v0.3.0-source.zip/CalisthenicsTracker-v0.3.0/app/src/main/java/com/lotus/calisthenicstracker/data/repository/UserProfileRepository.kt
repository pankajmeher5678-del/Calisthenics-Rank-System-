package com.lotus.calisthenicstracker.data.repository

import com.lotus.calisthenicstracker.data.dao.UserProfileDao
import com.lotus.calisthenicstracker.data.entity.UserProfileEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class UserProfileRepository(
    private val dao: UserProfileDao
) {

    fun observe(): Flow<UserProfileEntity?> = dao.observe()

    suspend fun getOrCreate(): UserProfileEntity {
        val existing = dao.get()

        if (existing != null) {
            return existing
        }

        val profile = UserProfileEntity(
            userId = UUID.randomUUID().toString(),
            displayName = "User",
            createdAt = System.currentTimeMillis()
        )

        dao.insert(profile)

        return profile
    }

    suspend fun updateName(name: String) {
        val existing = dao.get() ?: getOrCreate()

        dao.update(
            existing.copy(
                displayName = name
            )
        )
    }
}

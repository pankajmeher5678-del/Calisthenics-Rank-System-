package com.lotus.calisthenicstracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.lotus.calisthenicstracker.data.database.AppDatabase
import com.lotus.calisthenicstracker.sensor.StepCounterService
import com.lotus.calisthenicstracker.ui.MainScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    companion object {
        private const val ACTIVITY_RECOGNITION_REQUEST = 100
        private const val NOTIFICATION_REQUEST = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MainScreen()
        }

        requestRequiredPermissions()
    }

    private fun requestRequiredPermissions() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    NOTIFICATION_REQUEST
                )
                return
            }
        }

        requestActivityRecognition()
    }

    private fun requestActivityRecognition() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACTIVITY_RECOGNITION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),
                    ACTIVITY_RECOGNITION_REQUEST
                )
                return
            }
        }

        startTrackingIfEnabled()
    }

    private fun startTrackingIfEnabled() {

        CoroutineScope(Dispatchers.IO).launch {

            val settings =
                AppDatabase
                    .get(applicationContext)
                    .notificationSettingsDao()
                    .get()

            if (settings?.stepNotificationEnabled == true) {

                val intent =
                    Intent(
                        applicationContext,
                        StepCounterService::class.java
                    )

                ContextCompat.startForegroundService(
                    applicationContext,
                    intent
                )
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        when (requestCode) {

            NOTIFICATION_REQUEST -> {
                requestActivityRecognition()
            }

            ACTIVITY_RECOGNITION_REQUEST -> {

                if (
                    grantResults.isNotEmpty() &&
                    grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    startTrackingIfEnabled()
                }
            }
        }
    }
}

package com.lotus.calisthenicstracker.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notification_settings")
data class NotificationSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val stepNotificationEnabled: Boolean = true,
    val goalNotificationEnabled: Boolean = false,
    val dailyStepGoal: Int = 0
)

package com.lotus.calisthenicstracker.domain.skill

import com.lotus.calisthenicstracker.domain.rank.SkillRank

data class SkillStage(val name: String, val rank: SkillRank, val minimumReps: Int = 0, val minimumHoldSeconds: Int = 0)

object SkillCatalog {
    val skills = mapOf(
        "L-Sit" to listOf("Tuck", "Extended tuck", "One-leg", "Full L-sit"),
        "Handstand" to listOf("Wall", "Freestanding", "Controlled hold"),
        "Front Lever" to listOf("Tuck", "Advanced tuck", "One-leg", "Full"),
        "Muscle-up" to listOf("Pull-up foundation", "High pull-up", "Transition", "Muscle-up")
    )

    // Numeric requirements remain configurable; these are starter defaults, not medical or performance guarantees.
    val defaultStages = mapOf(
        "L-Sit" to listOf(
            SkillStage("Tuck", SkillRank.WOOD, minimumHoldSeconds = 10),
            SkillStage("Extended tuck", SkillRank.BRONZE, minimumHoldSeconds = 10),
            SkillStage("One-leg", SkillRank.SILVER, minimumHoldSeconds = 10),
            SkillStage("Full L-sit", SkillRank.GOLD, minimumHoldSeconds = 10)
        ),
        "Handstand" to listOf(
            SkillStage("Wall", SkillRank.WOOD, minimumHoldSeconds = 20),
            SkillStage("Freestanding", SkillRank.SILVER, minimumHoldSeconds = 10),
            SkillStage("Controlled hold", SkillRank.GOLD, minimumHoldSeconds = 20)
        )
    )
}

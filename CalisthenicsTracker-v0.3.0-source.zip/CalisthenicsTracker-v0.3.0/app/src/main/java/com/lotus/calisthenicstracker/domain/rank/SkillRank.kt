package com.lotus.calisthenicstracker.domain.rank

enum class SkillRank(val label: String) {
    WOOD("Wood"), BRONZE("Bronze"), SILVER("Silver"), GOLD("Gold"),
    PLATINUM("Platinum"), DIAMOND("Diamond"), CHAMPION("Champion"), TITAN("Titan"), OLYMPIAN("Olympian")
}

data class SkillProgress(
    val skill: String,
    val stage: String,
    val rank: SkillRank,
    val verified: Boolean
)

package com.lotus.calisthenicstracker.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lotus.calisthenicstracker.data.database.AppDatabase
import com.lotus.calisthenicstracker.data.entity.NotificationSettingsEntity
import com.lotus.calisthenicstracker.data.repository.NotificationSettingsRepository
import com.lotus.calisthenicstracker.sensor.StepCounterService
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotificationSettingsViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository =
        NotificationSettingsRepository(
            AppDatabase
                .get(application)
                .notificationSettingsDao()
        )

    val settings: StateFlow<NotificationSettingsEntity?> =
        repository.observe().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            null
        )

    init {
        viewModelScope.launch {
            repository.getOrCreate()
        }
    }

    fun setStepNotificationEnabled(enabled: Boolean) {

        viewModelScope.launch {

            repository.setStepNotificationEnabled(
                enabled
            )

            if (enabled) {
                startStepTracking()
            } else {
                stopStepTracking()
            }
        }
    }

    fun setGoalNotificationEnabled(enabled: Boolean) {

        viewModelScope.launch {
            repository.setGoalNotificationEnabled(
                enabled
            )
        }
    }

    fun setDailyStepGoal(goal: Int) {

        viewModelScope.launch {

            repository.setDailyStepGoal(
                goal
            )

            if (goal <= 0) {
                repository.setGoalNotificationEnabled(
                    false
                )
            }
        }
    }

    private fun startStepTracking() {

        val context = getApplication<Application>()

        val intent =
            Intent(
                context,
                StepCounterService::class.java
            )

        ContextCompat.startForegroundService(
            context,
            intent
        )
    }

    private fun stopStepTracking() {

        val context = getApplication<Application>()

        val intent =
            Intent(
                context,
                StepCounterService::class.java
            )

        context.stopService(intent)
    }
}

package com.lotus.calisthenicstracker.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.lotus.calisthenicstracker.data.entity.StepRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StepDao {
    @Insert suspend fun insert(record: StepRecordEntity): Long
    @Query("SELECT * FROM step_records ORDER BY dayStart DESC") fun observeAll(): Flow<List<StepRecordEntity>>
    @Query("SELECT steps FROM step_records WHERE dayStart = :day LIMIT 1") suspend fun get(day: Long): Long?
    @Query("UPDATE step_records SET steps = :steps WHERE dayStart = :day") suspend fun update(day: Long, steps: Long)
}

package com.lotus.calisthenicstracker.domain.detection

import com.lotus.calisthenicstracker.domain.workout.MovementPhase

class DipDetector : ExerciseDetector {
    override fun phase(p: Map<String, Point2D>): MovementPhase {
        val shoulder=p["shoulder"]?:return MovementPhase.UNKNOWN
        val elbow=p["elbow"]?:return MovementPhase.UNKNOWN
        val wrist=p["wrist"]?:return MovementPhase.UNKNOWN
        if (!PoseMath.confident(shoulder,elbow,wrist)) return MovementPhase.UNKNOWN
        val a=PoseMath.angle(shoulder,elbow,wrist)
        return when { a>155f->MovementPhase.TOP; a<90f->MovementPhase.BOTTOM; a<130f->MovementPhase.DESCENDING; else->MovementPhase.ASCENDING }
    }
}

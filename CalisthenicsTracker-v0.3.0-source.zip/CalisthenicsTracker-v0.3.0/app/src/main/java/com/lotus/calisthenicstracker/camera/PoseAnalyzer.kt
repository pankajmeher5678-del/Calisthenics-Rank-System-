package com.lotus.calisthenicstracker.camera

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.lotus.calisthenicstracker.domain.detection.ExerciseDetector
import com.lotus.calisthenicstracker.domain.detection.Point2D
import com.lotus.calisthenicstracker.domain.workout.MovementPhase
import com.lotus.calisthenicstracker.domain.workout.RepStatus
import com.lotus.calisthenicstracker.domain.workout.RepValidator

class PoseAnalyzer(
    private val detector: ExerciseDetector,
    private val validator: RepValidator,
    private val onPhase: (MovementPhase) -> Unit,
    private val onRep: (RepStatus) -> Unit
) : ImageAnalysis.Analyzer {
    private val poseDetector = PoseDetection.getClient(
        PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
    )

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        poseDetector.process(image)
            .addOnSuccessListener { pose -> handlePose(pose) }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun handlePose(pose: Pose) {
        val phase = detector.phase(poseLandmarks(pose))
        onPhase(phase)
        val status = validator.update(phase)
        if (status != RepStatus.NONE) onRep(status)
    }

    private fun poseLandmarks(pose: Pose): Map<String, Point2D> {
        fun point(type: Int): Point2D? = pose.getPoseLandmark(type)?.let {
            Point2D(it.position.x, it.position.y, it.inFrameLikelihood)
        }
        val shoulder = point(PoseLandmark.LEFT_SHOULDER)
        val elbow = point(PoseLandmark.LEFT_ELBOW)
        val wrist = point(PoseLandmark.LEFT_WRIST)
        val hip = point(PoseLandmark.LEFT_HIP)
        val knee = point(PoseLandmark.LEFT_KNEE)
        val ankle = point(PoseLandmark.LEFT_ANKLE)
        return buildMap {
            if (shoulder != null) put("shoulder", shoulder)
            if (elbow != null) put("elbow", elbow)
            if (wrist != null) put("wrist", wrist)
            if (hip != null) put("hip", hip)
            if (knee != null) put("knee", knee)
            if (ankle != null) put("ankle", ankle)
        }
    }

    fun close() = poseDetector.close()
}

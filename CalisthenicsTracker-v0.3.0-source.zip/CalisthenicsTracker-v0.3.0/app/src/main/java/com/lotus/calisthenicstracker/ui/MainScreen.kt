package com.lotus.calisthenicstracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lotus.calisthenicstracker.domain.rank.*
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun MainScreen() {
    var selected by remember { mutableIntStateOf(0) }
    var activeExercise by remember { mutableStateOf<Exercise?>(null) }

    val workoutViewModel: WorkoutViewModel = viewModel()
    val profileViewModel: UserProfileViewModel = viewModel()
    val profile by profileViewModel.profile.collectAsState()

    if (activeExercise != null) {
        CameraWorkoutScreen(
            exercise = activeExercise!!,
            viewModel = workoutViewModel,
            onBack = { activeExercise = null }
        )
        return
    }

    val displayName = profile?.displayName ?: "User"

    val tabs = listOf("Home", "Workout", "Ranks", "Progress", "Profile")

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, title ->
                    NavigationBarItem(
                        selected = selected == i,
                        onClick = { selected = i },
                        icon = {},
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { pad ->

        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
        ) {

            Text(
                text = "Hi, $displayName",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(
                    start = 20.dp,
                    top = 16.dp,
                    end = 20.dp,
                    bottom = 8.dp
                )
            )

            when (selected) {
                0 -> HomeScreen(Modifier.weight(1f))
                1 -> WorkoutScreen(Modifier.weight(1f)) { exercise ->
                    workoutViewModel.selectExercise(exercise)
                    activeExercise = exercise
                }
                2 -> RanksScreen(Modifier.weight(1f))
                3 -> ProgressScreen(Modifier.weight(1f))
                else -> ProfileScreen(
                    Modifier.weight(1f),
                    profileViewModel = profileViewModel,
                    currentName = displayName
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(m: Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current

    val stepRepository = remember {
        com.lotus.calisthenicstracker.data.repository.StepRepository(
            com.lotus.calisthenicstracker.data.database.AppDatabase
                .get(context)
                .stepDao()
        )
    }

    val history by stepRepository
        .observeHistory()
        .collectAsState(initial = emptyList())

    val todaySteps = history.firstOrNull()?.steps ?: 0L

    Column(
        m.padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Calisthenics Tracker",
            style = MaterialTheme.typography.headlineMedium
        )

        RankCard(
            "Rep Rank",
            "Wood",
            "Based on your weakest core exercise PR."
        )

        RankCard(
            "Skill Rank",
            "Wood",
            "Independent from the rep ladder."
        )

        RankCard(
            "Steps",
            "$todaySteps today",
            "Tracked separately from workout reps."
        )
    }
}

@Composable
private fun RankCard(
    title: String,
    value: String,
    note: String
) = Card {
    Column(Modifier.padding(16.dp)) {
        Text(title)
        Text(
            value,
            style = MaterialTheme.typography.headlineSmall
        )
        Text(note)
    }
}

@Composable
private fun WorkoutScreen(
    m: Modifier,
    onStart: (Exercise) -> Unit
) = Column(
    m.padding(20.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
) {
    Text(
        "Workout",
        style = MaterialTheme.typography.headlineMedium
    )

    listOf(
        Exercise.PUSH_UP,
        Exercise.PULL_UP,
        Exercise.SQUAT,
        Exercise.DIP
    ).forEach { exercise ->

        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(exerciseLabel(exercise))

                Button(
                    onClick = { onStart(exercise) }
                ) {
                    Text("Start")
                }
            }
        }
    }
}

@Composable
private fun RanksScreen(m: Modifier) = LazyColumn(
    m.padding(20.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
) {
    item {
        Text(
            "Rep Rank",
            style = MaterialTheme.typography.headlineMedium
        )
    }

    items(RepRank.entries) { rank ->
        Text(
            "${rank.label}: Push-ups ${
                RepRequirements.minimum(Exercise.PUSH_UP, rank)
            }+ • Pull-ups ${
                RepRequirements.minimum(Exercise.PULL_UP, rank)
            }+ • Squats ${
                RepRequirements.minimum(Exercise.SQUAT, rank)
            }+"
        )
    }

    item {
        Spacer(Modifier.height(16.dp))

        Text(
            "Skill Rank",
            style = MaterialTheme.typography.headlineMedium
        )
    }

    items(SkillRank.entries) {
        Text(it.label)
    }
}

@Composable
private fun ProgressScreen(m: Modifier) {
    val vm: WorkoutViewModel = viewModel()
    val workouts by vm.history.collectAsState(initial = emptyList())

    Column(
        m.padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "Progress",
            style = MaterialTheme.typography.headlineMedium
        )

        Text("Saved workouts: ${workouts.size}")

        if (workouts.isEmpty()) {
            Text("Complete a camera workout to start your history.")
        }

        workouts.take(20).forEach { workout ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${workout.totalReps} verified reps")

                    Text(
                        "Started: ${
                            java.text.DateFormat
                                .getDateTimeInstance()
                                .format(java.util.Date(workout.startedAt))
                        }"
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(
    m: Modifier,
    profileViewModel: UserProfileViewModel,
    currentName: String
) {
    var editing by remember { mutableStateOf(false) }
    var name by remember(currentName) { mutableStateOf(currentName) }

    Column(
        m.padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Profile",
            style = MaterialTheme.typography.headlineMedium
        )

        if (editing) {

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Display name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        profileViewModel.updateName(name)
                        editing = false
                    }
                ) {
                    Text("Save")
                }

                OutlinedButton(
                    onClick = {
                        name = currentName
                        editing = false
                    }
                ) {
                    Text("Cancel")
                }
            }

        } else {

            Text(
                currentName,
                style = MaterialTheme.typography.headlineSmall
            )

            Button(
                onClick = { editing = true }
            ) {
                Text("Edit Name")
            }
        }

        Text("Permissions: Camera and Activity Recognition")
        Text("Minimum Android version: Android 10 (API 29)")
    }
}

private fun exerciseLabel(exercise: Exercise) = when (exercise) {
    Exercise.PUSH_UP -> "Push-ups"
    Exercise.PULL_UP -> "Pull-ups"
    Exercise.SQUAT -> "Squats"
    Exercise.DIP -> "Dips"
}

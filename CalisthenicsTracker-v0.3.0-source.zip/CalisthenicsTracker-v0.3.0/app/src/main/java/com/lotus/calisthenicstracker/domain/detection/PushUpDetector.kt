package com.lotus.calisthenicstracker.domain.detection

import com.lotus.calisthenicstracker.domain.workout.MovementPhase

class PushUpDetector : ExerciseDetector {
    override fun phase(p: Map<String, Point2D>): MovementPhase {
        val shoulder = p["shoulder"] ?: return MovementPhase.UNKNOWN
        val elbow = p["elbow"] ?: return MovementPhase.UNKNOWN
        val wrist = p["wrist"] ?: return MovementPhase.UNKNOWN
        if (!PoseMath.confident(shoulder, elbow, wrist)) return MovementPhase.UNKNOWN
        val elbowAngle = PoseMath.angle(shoulder, elbow, wrist)
        return when {
            elbowAngle > 155f -> MovementPhase.TOP
            elbowAngle < 100f -> MovementPhase.BOTTOM
            elbowAngle < 135f -> MovementPhase.DESCENDING
            else -> MovementPhase.ASCENDING
        }
    }
}

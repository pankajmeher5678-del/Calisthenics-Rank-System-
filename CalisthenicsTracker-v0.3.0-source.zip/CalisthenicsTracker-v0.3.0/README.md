# Calisthenics Tracker

Real Android Studio project for the LOTUS calisthenics tracker.

## Current implementation
- Kotlin + Jetpack Compose
- Android 10+ (API 29+)
- Separate Rep Rank and Skill Rank systems
- Exercise-specific Wood -> Olympian rep thresholds for push-ups, pull-ups and squats
- Weakest-core-exercise overall Rep Rank calculation
- Room workout/set/PR persistence foundation
- Rep-validation state machine
- Pose-math foundation for camera detection
- Camera and Activity Recognition permissions
- CameraX + ML Kit Pose dependencies prepared

## Current implementation
- CameraX preview + ML Kit pose analyzer
- Push-up/squat/pull-up/dip landmark detectors
- Live verified-rep UI
- Room workout persistence and workout history
- Workout repository/ViewModel integration

## Remaining implementation
1. Step baseline + daily step history
2. Health Connect integration
3. Configurable skill verification workflow
4. Full analytics/rank history
5. Backup/export/restore
6. Release signing and APK/AAB build

## Build
Open this directory in Android Studio and let Gradle sync. The current workspace used to generate this archive does not contain an Android SDK, so no APK is claimed to have been compiled here.

## Build 30 additions
- Persistent daily step records using Android TYPE_STEP_COUNTER.
- SkillCatalog with independent, configurable skill stages.
- JSON workout backup export/validation foundation.
- PR insertion now only occurs when a new verified maximum is achieved.
- Room database schema version 2.

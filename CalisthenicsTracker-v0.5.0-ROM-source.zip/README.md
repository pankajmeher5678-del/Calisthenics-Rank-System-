# Calisthenics Tracker v0.5.0

Android 10+ Kotlin / Jetpack Compose calisthenics tracker for LOTUS.

## This update
- Profile-driven range-of-motion (ROM) engine shared by exercise detectors.
- Confidence-gated pose landmarks and highest-confidence left/right landmark selection.
- ROM profiles for push-ups, dips, pull-ups/chin-ups, curls, rows, overhead presses, triceps extensions, squats, lunges, step-ups, knee extensions, hamstring curls, hip hinges, glute bridges, leg raises, sit-ups/crunches, calf raises, shoulder raises, wrist curls and neck movement.
- 45+ built-in exercise variations and custom exercises. Custom exercises can be created in-app and assigned to a reusable ROM profile without an APK update; select the closest movement pattern.
- Home and Progress tabs show personal records across all supported exercise categories.
- Cultivation-themed Rep Rank and Skill Rank systems remain separate.
- Application ID remains `com.lotus.calisthenicstracker`; version code is 5 and version name is 0.5.0.

## ROM limitations
A single phone camera is not a universal 3D motion-capture system. Thresholds are configurable starting heuristics and vary by camera angle, body proportions, lighting, and exercise execution. Side-on framing is recommended for most profiles. Isometric holds (for example, planks and L-sits) need time-based validation rather than repetition counting. Every profile should be tested on a real phone before treating its counts as verified.

## Stable APK updates
The workflow supports a persistent release keystore via GitHub Actions repository secrets:
- `ANDROID_KEYSTORE_BASE64` — base64-encoded JKS/keystore file
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Keep the keystore and passwords private and backed up. Use the same key for every future release. If these secrets are absent, the workflow creates a debug APK and explicitly labels it as not guaranteed to update over an APK signed with another key. Because earlier debug builds may have used temporary runner keys, an older installed APK may need to be uninstalled once before installing the first persistently signed release; uninstalling may erase local app data.

## Build
Open the project in Android Studio, sync Gradle, and build. GitHub Actions builds an APK artifact on pushes to `main` or manual workflow dispatch. Source ZIP is not an APK.

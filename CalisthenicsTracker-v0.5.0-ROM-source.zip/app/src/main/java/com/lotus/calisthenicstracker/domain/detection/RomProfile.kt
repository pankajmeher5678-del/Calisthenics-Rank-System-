package com.lotus.calisthenicstracker.domain.detection

import com.lotus.calisthenicstracker.domain.workout.MovementPhase

/**
 * Camera-independent ROM rule. Angles use three landmarks: angle at jointB
 * between jointA-jointB and jointC-jointB. Values are starting defaults, not
 * medical standards; users should keep the whole body visible and use a side view.
 */
enum class RomDirection { EXTEND_TO_TOP, FLEX_TO_TOP }

data class RomProfile(
    val id: String,
    val displayName: String,
    val jointA: String,
    val jointB: String,
    val jointC: String,
    val topAngle: Float,
    val bottomAngle: Float,
    val direction: RomDirection = RomDirection.EXTEND_TO_TOP,
    val minimumConfidence: Float = .68f,
    val alignmentA: String? = null,
    val alignmentB: String? = null,
    val minimumAlignmentAngle: Float? = null,
    val hangAtBottom: Boolean = false
)

/** Generic ROM detector shared by exercise variations. Add a catalog entry instead of a new detector class. */
class ProfileRomDetector(private val profile: RomProfile) : ExerciseDetector {
    private var previousAngle: Float? = null

    override fun phase(points: Map<String, Point2D>): MovementPhase {
        val a = points[profile.jointA] ?: return MovementPhase.UNKNOWN
        val b = points[profile.jointB] ?: return MovementPhase.UNKNOWN
        val c = points[profile.jointC] ?: return MovementPhase.UNKNOWN
        if (!PoseMath.confident(a, b, c, min = profile.minimumConfidence)) return MovementPhase.UNKNOWN
        val alignA = profile.alignmentA?.let(points::get)
        val alignB = profile.alignmentB?.let(points::get)
        val minAlign = profile.minimumAlignmentAngle
        if (alignA != null && alignB != null && minAlign != null &&
            PoseMath.confident(a, alignA, alignB, min = .60f) &&
            PoseMath.angle(a, alignA, alignB) < minAlign) return MovementPhase.UNKNOWN

        val angle = PoseMath.angle(a, b, c)
        val previous = previousAngle
        previousAngle = angle
        return if (profile.direction == RomDirection.EXTEND_TO_TOP) {
            when {
                angle >= profile.topAngle -> MovementPhase.TOP
                angle <= profile.bottomAngle -> MovementPhase.BOTTOM
                previous == null -> MovementPhase.UNKNOWN
                angle > previous + 1.5f -> MovementPhase.ASCENDING
                angle < previous - 1.5f -> MovementPhase.DESCENDING
                else -> MovementPhase.UNKNOWN
            }
        } else {
            when {
                angle <= profile.bottomAngle -> MovementPhase.TOP
                angle >= profile.topAngle -> if (profile.hangAtBottom) MovementPhase.HANG else MovementPhase.BOTTOM
                previous == null -> MovementPhase.UNKNOWN
                angle < previous - 1.5f -> MovementPhase.ASCENDING
                angle > previous + 1.5f -> MovementPhase.DESCENDING
                else -> MovementPhase.UNKNOWN
            }
        }
    }
}

/** Reusable profiles for common strength and bodyweight movement families. */
object RomProfileCatalog {
    private fun elbow(id: String, name: String, direction: RomDirection = RomDirection.EXTEND_TO_TOP,
                      top: Float = 160f, bottom: Float = 90f) =
        RomProfile(id, name, "shoulder", "elbow", "wrist", top, bottom, direction)
    private fun knee(id: String, name: String, bottom: Float = 105f,
                     direction: RomDirection = RomDirection.EXTEND_TO_TOP, top: Float = 160f) =
        RomProfile(id, name, "hip", "knee", "ankle", top, bottom, direction)
    private fun hip(id: String, name: String, direction: RomDirection = RomDirection.EXTEND_TO_TOP,
                    top: Float = 160f, bottom: Float = 105f) =
        RomProfile(id, name, "shoulder", "hip", "knee", top, bottom, direction)

    val profiles: List<RomProfile> = listOf(
        elbow("push", "Push-up / horizontal press", top = 162f, bottom = 88f),
        elbow("dip", "Dip / triceps press", top = 158f, bottom = 88f),
        elbow("pull", "Pull-up / chin-up", RomDirection.FLEX_TO_TOP, top = 158f, bottom = 72f).copy(hangAtBottom = true),
        elbow("curl", "Biceps curl", RomDirection.FLEX_TO_TOP, top = 155f, bottom = 65f),
        elbow("row", "Row / horizontal pull", RomDirection.FLEX_TO_TOP, top = 150f, bottom = 85f),
        elbow("overhead-press", "Overhead press", top = 160f, bottom = 85f),
        elbow("triceps-extension", "Triceps extension", top = 160f, bottom = 75f),
        knee("squat", "Squat", 105f),
        knee("lunge", "Lunge / split squat", 105f),
        knee("step-up", "Step-up", 100f),
        knee("knee-extension", "Knee extension", 70f),
        knee("hamstring-curl", "Hamstring curl", 75f, RomDirection.FLEX_TO_TOP, 165f),
        hip("hip-hinge", "Hip hinge / good morning", top = 165f, bottom = 115f),
        hip("glute-bridge", "Glute bridge", top = 165f, bottom = 115f),
        hip("leg-raise", "Leg raise / knee raise", RomDirection.FLEX_TO_TOP, top = 165f, bottom = 100f),
        hip("sit-up", "Sit-up / crunch", RomDirection.FLEX_TO_TOP, top = 160f, bottom = 95f),
        RomProfile("calf-raise", "Calf raise", "knee", "ankle", "toe", 150f, 105f),
        RomProfile("shoulder-raise", "Lateral / front raise", "elbow", "shoulder", "hip", 125f, 35f,
            RomDirection.EXTEND_TO_TOP, .62f),
        RomProfile("wrist-curl", "Wrist curl", "elbow", "wrist", "finger", 165f, 120f),
        RomProfile("neck-mobility", "Neck mobility", "shoulder", "ear", "nose", 155f, 115f, minimumConfidence = .75f)
    )

    private val byId = profiles.associateBy { it.id }
    fun get(id: String): RomProfile = byId[id] ?: byId.getValue("push")

    /** Catalog maps many named exercises to reusable ROM families; no bespoke detector is needed per variation. */
    val exerciseToProfile: Map<String, String> = mapOfEntries(
        "Incline Push-up" to "push", "Knee Push-up" to "push", "Standard Push-up" to "push",
        "Close-Grip Push-up" to "push", "Decline Push-up" to "push", "Archer Push-up" to "push",
        "Diamond Push-up" to "push", "Pike Push-up" to "push", "Pseudo Planche Push-up" to "push",
        "Wide Push-up" to "push", "Hindu Push-up" to "push", "Handstand Push-up" to "overhead-press",
        "Scapular Pull-up" to "pull", "Band-Assisted Pull-up" to "pull", "Strict Pull-up" to "pull",
        "Chin-up" to "pull", "Chest-to-Bar Pull-up" to "pull", "Commando Pull-up" to "pull",
        "Inverted Row" to "row", "Australian Pull-up" to "row", "Ring Row" to "row",
        "Bodyweight Squat" to "squat", "Tempo Squat" to "squat", "Jump Squat" to "squat",
        "Reverse Lunge" to "lunge", "Walking Lunge" to "lunge", "Bulgarian Split Squat" to "lunge",
        "Pistol Squat Progression" to "squat", "Step-up" to "step-up", "Calf Raise" to "calf-raise",
        "Bench Dip" to "dip", "Parallel-Bar Dip" to "dip", "Straight-Bar Dip" to "dip",
        "Biceps Curl" to "curl", "Hammer Curl" to "curl", "Band Curl" to "curl",
        "Overhead Press" to "overhead-press", "Pike Press" to "overhead-press",
        "Triceps Extension" to "triceps-extension", "Band Triceps Pushdown" to "triceps-extension",
        "Good Morning" to "hip-hinge", "Hip Hinge" to "hip-hinge", "Glute Bridge" to "glute-bridge",
        "Single-Leg Glute Bridge" to "glute-bridge", "Hanging Knee Raise" to "leg-raise",
        "Hanging Leg Raise" to "leg-raise", "Lying Leg Raise" to "leg-raise", "Sit-up" to "sit-up",
        "Crunch" to "sit-up", "Bicycle Crunch" to "sit-up", "Wrist Curl" to "wrist-curl",
        "Lateral Raise" to "shoulder-raise", "Front Raise" to "shoulder-raise"
    )

    private fun mapOfEntries(vararg pairs: Pair<String, String>): Map<String, String> = pairs.toMap()
}

package com.lotus.calisthenicstracker.camera

import android.annotation.SuppressLint
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.lotus.calisthenicstracker.domain.detection.ExerciseDetector
import com.lotus.calisthenicstracker.domain.detection.Point2D
import com.lotus.calisthenicstracker.domain.workout.MovementPhase
import com.lotus.calisthenicstracker.domain.workout.RepStatus
import com.lotus.calisthenicstracker.domain.workout.RepValidator

class PoseAnalyzer(
    private val detector: ExerciseDetector,
    private val validator: RepValidator,
    private val onPhase: (MovementPhase) -> Unit,
    private val onRep: (RepStatus) -> Unit
) : ImageAnalysis.Analyzer {
    private val poseDetector = PoseDetection.getClient(
        PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
    )

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        poseDetector.process(image)
            .addOnSuccessListener { pose -> handlePose(pose) }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun handlePose(pose: Pose) {
        val phase = detector.phase(poseLandmarks(pose))
        onPhase(phase)
        val status = validator.update(phase)
        if (status != RepStatus.NONE) onRep(status)
    }

    private fun poseLandmarks(pose: Pose): Map<String, Point2D> {
        val leftTypes = intArrayOf(
            PoseLandmark.LEFT_SHOULDER, PoseLandmark.LEFT_ELBOW, PoseLandmark.LEFT_WRIST,
            PoseLandmark.LEFT_HIP, PoseLandmark.LEFT_KNEE, PoseLandmark.LEFT_ANKLE
        )
        val rightTypes = intArrayOf(
            PoseLandmark.RIGHT_SHOULDER, PoseLandmark.RIGHT_ELBOW, PoseLandmark.RIGHT_WRIST,
            PoseLandmark.RIGHT_HIP, PoseLandmark.RIGHT_KNEE, PoseLandmark.RIGHT_ANKLE
        )
        fun confidence(type: Int): Float = pose.getPoseLandmark(type)?.inFrameLikelihood ?: 0f
        val leftScore = leftTypes.map(::confidence).average()
        val rightScore = rightTypes.map(::confidence).average()
        val preferLeft = leftScore >= rightScore

        fun point(leftType: Int, rightType: Int): Point2D? {
            val firstType = if (preferLeft) leftType else rightType
            val secondType = if (preferLeft) rightType else leftType
            val first = pose.getPoseLandmark(firstType)?.let {
                Point2D(it.position.x, it.position.y, it.inFrameLikelihood)
            }
            val second = pose.getPoseLandmark(secondType)?.let {
                Point2D(it.position.x, it.position.y, it.inFrameLikelihood)
            }
            return when {
                first == null -> second
                second == null -> first
                first.confidence >= .45f -> first
                else -> second
            }
        }

        val shoulder = point(PoseLandmark.LEFT_SHOULDER, PoseLandmark.RIGHT_SHOULDER)
        val elbow = point(PoseLandmark.LEFT_ELBOW, PoseLandmark.RIGHT_ELBOW)
        val wrist = point(PoseLandmark.LEFT_WRIST, PoseLandmark.RIGHT_WRIST)
        val hip = point(PoseLandmark.LEFT_HIP, PoseLandmark.RIGHT_HIP)
        val knee = point(PoseLandmark.LEFT_KNEE, PoseLandmark.RIGHT_KNEE)
        val ankle = point(PoseLandmark.LEFT_ANKLE, PoseLandmark.RIGHT_ANKLE)
        val toe = point(PoseLandmark.LEFT_FOOT_INDEX, PoseLandmark.RIGHT_FOOT_INDEX)
        val ear = point(PoseLandmark.LEFT_EAR, PoseLandmark.RIGHT_EAR)
        val nose = pose.getPoseLandmark(PoseLandmark.NOSE)?.let {
            Point2D(it.position.x, it.position.y, it.inFrameLikelihood)
        }
        val finger = point(PoseLandmark.LEFT_INDEX, PoseLandmark.RIGHT_INDEX)
        return buildMap {
            if (shoulder != null) put("shoulder", shoulder)
            if (elbow != null) put("elbow", elbow)
            if (wrist != null) put("wrist", wrist)
            if (hip != null) put("hip", hip)
            if (knee != null) put("knee", knee)
            if (ankle != null) put("ankle", ankle)
            if (toe != null) put("toe", toe)
            if (ear != null) put("ear", ear)
            if (nose != null) put("nose", nose)
            if (finger != null) put("finger", finger)
        }
    }

    fun close() = poseDetector.close()
}

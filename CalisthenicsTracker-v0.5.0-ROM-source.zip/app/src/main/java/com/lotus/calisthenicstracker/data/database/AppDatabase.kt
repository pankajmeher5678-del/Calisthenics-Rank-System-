package com.lotus.calisthenicstracker.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Room
import android.content.Context
import com.lotus.calisthenicstracker.data.dao.WorkoutDao
import com.lotus.calisthenicstracker.data.entity.*

@Database(entities = [WorkoutEntity::class, SetEntity::class, PersonalRecordEntity::class], version = 3, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun workoutDao(): WorkoutDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "calisthenics_tracker.db"
            ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}

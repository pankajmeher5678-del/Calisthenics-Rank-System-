package com.lotus.calisthenicstracker.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.content.SharedPreferences
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lotus.calisthenicstracker.domain.rank.*
import com.lotus.calisthenicstracker.domain.detection.RomProfileCatalog

private data class RankInfo(val title: String, val description: String, val tier: String? = null)
private data class ExerciseVariation(
    val name: String, val base: Exercise, val romProfile: String, val group: String,
    val unlockRank: Int, val detail: String, val symbol: String, val custom: Boolean = false
)
private val subRanks = listOf(
    "Qi Initiate" to "Learn the movement standard and build safe, repeatable technique.",
    "Foundation Disciple" to "Build controlled repetitions and stable positions.",
    "Inner-Core Adept" to "Demonstrate consistent quality across sessions.",
    "Realm Breakthrough" to "Meet the rank target before advancing to the next realm."
)
private val variations = listOf(
    ExerciseVariation("Incline Push-up", Exercise.PUSH_UP, "push", "Push", 0, "Beginner press; use a stable elevated surface.", "↗"),
    ExerciseVariation("Knee Push-up", Exercise.PUSH_UP, "push", "Push", 0, "Regress the lever while keeping the torso aligned.", "◇"),
    ExerciseVariation("Standard Push-up", Exercise.PUSH_UP, "push", "Push", 0, "Controlled chest-to-floor pressing range.", "✦"),
    ExerciseVariation("Close-Grip Push-up", Exercise.PUSH_UP, "push", "Push", 2, "More triceps emphasis; keep wrists comfortable.", "✧"),
    ExerciseVariation("Decline Push-up", Exercise.PUSH_UP, "push", "Push", 4, "Feet elevated on a secure surface.", "⬆"),
    ExerciseVariation("Diamond Push-up", Exercise.PUSH_UP, "push", "Push", 5, "Narrow hand position; stop if wrists hurt.", "◇"),
    ExerciseVariation("Archer Push-up", Exercise.PUSH_UP, "push", "Push", 8, "Uneven loading; progress gradually.", "➶"),
    ExerciseVariation("Pike Push-up", Exercise.SHOULDER_PRESS, "overhead-press", "Shoulders", 4, "Shoulder-focused press; keep head path controlled.", "↟"),
    ExerciseVariation("Scapular Pull-up", Exercise.PULL_UP, "pull", "Pull", 0, "Practice shoulder-blade control from a secure bar.", "⌁"),
    ExerciseVariation("Band-Assisted Pull-up", Exercise.PULL_UP, "pull", "Pull", 0, "Use a securely anchored assistance band.", "↟"),
    ExerciseVariation("Strict Pull-up", Exercise.PULL_UP, "pull", "Pull", 2, "Controlled hang-to-top range without swinging.", "↑"),
    ExerciseVariation("Chin-up", Exercise.PULL_UP, "pull", "Pull", 3, "Supinated grip; use a secure bar.", "⇡"),
    ExerciseVariation("Chest-to-Bar Pull-up", Exercise.PULL_UP, "pull", "Pull", 7, "Higher pulling range; avoid kipping.", "✦"),
    ExerciseVariation("Inverted Row", Exercise.ROW, "row", "Pull", 1, "Keep body aligned under a secure bar or rings.", "↔"),
    ExerciseVariation("Australian Pull-up", Exercise.ROW, "row", "Pull", 1, "Horizontal pulling with a stable setup.", "↔"),
    ExerciseVariation("Bodyweight Squat", Exercise.SQUAT, "squat", "Legs", 0, "Squat to a comfortable, controlled depth.", "◉"),
    ExerciseVariation("Tempo Squat", Exercise.SQUAT, "squat", "Legs", 1, "Slow lowering phase to build control.", "◌"),
    ExerciseVariation("Jump Squat", Exercise.SQUAT, "squat", "Legs", 4, "Land softly; use only when pain-free and ready.", "✧"),
    ExerciseVariation("Reverse Lunge", Exercise.LUNGE, "lunge", "Legs", 2, "Train each leg with stable balance.", "↘"),
    ExerciseVariation("Walking Lunge", Exercise.LUNGE, "lunge", "Legs", 3, "Use controlled steps and clear floor space.", "↘"),
    ExerciseVariation("Bulgarian Split Squat", Exercise.LUNGE, "lunge", "Legs", 5, "Rear foot on a stable support.", "⟋"),
    ExerciseVariation("Pistol Squat Progression", Exercise.SQUAT, "squat", "Legs", 9, "Use assisted progressions before full reps.", "◎"),
    ExerciseVariation("Step-up", Exercise.STEP_UP, "step-up", "Legs", 2, "Use a low, stable step.", "↥"),
    ExerciseVariation("Calf Raise", Exercise.CALF_RAISE, "calf-raise", "Legs", 0, "Rise and lower through a comfortable ankle range.", "⌃"),
    ExerciseVariation("Bench Dip", Exercise.DIP, "dip", "Push", 0, "Stable support and pain-free shoulder range only.", "⌄"),
    ExerciseVariation("Parallel-Bar Dip", Exercise.DIP, "dip", "Push", 3, "Keep shoulders controlled; do not force depth.", "⋀"),
    ExerciseVariation("Straight-Bar Dip", Exercise.DIP, "dip", "Push", 6, "Requires stable bar support and shoulder control.", "⌃"),
    ExerciseVariation("Biceps Curl", Exercise.BICEP_CURL, "curl", "Arms", 0, "Keep elbows steady and avoid swinging.", "↻"),
    ExerciseVariation("Hammer Curl", Exercise.BICEP_CURL, "curl", "Arms", 1, "Neutral grip; move with control.", "↻"),
    ExerciseVariation("Band Curl", Exercise.BICEP_CURL, "curl", "Arms", 0, "Anchor band securely and control the return.", "↻"),
    ExerciseVariation("Overhead Press", Exercise.SHOULDER_PRESS, "overhead-press", "Shoulders", 3, "Press in a comfortable shoulder path.", "↑"),
    ExerciseVariation("Lateral Raise", Exercise.SHOULDER_RAISE, "shoulder-raise", "Shoulders", 2, "Use light resistance and controlled shoulder motion.", "↗"),
    ExerciseVariation("Front Raise", Exercise.SHOULDER_RAISE, "shoulder-raise", "Shoulders", 2, "Avoid swinging or shrugging excessively.", "↗"),
    ExerciseVariation("Triceps Extension", Exercise.TRICEPS_EXTENSION, "triceps-extension", "Arms", 1, "Keep upper arms stable.", "↕"),
    ExerciseVariation("Band Triceps Pushdown", Exercise.TRICEPS_EXTENSION, "triceps-extension", "Arms", 0, "Anchor band securely; extend without snapping elbows.", "↕"),
    ExerciseVariation("Good Morning", Exercise.HIP_HINGE, "hip-hinge", "Core & Hips", 3, "Hinge at hips while keeping spine neutral.", "↘"),
    ExerciseVariation("Glute Bridge", Exercise.GLUTE_BRIDGE, "glute-bridge", "Core & Hips", 0, "Lift hips without over-arching the lower back.", "⌒"),
    ExerciseVariation("Single-Leg Glute Bridge", Exercise.GLUTE_BRIDGE, "glute-bridge", "Core & Hips", 4, "Keep pelvis level through the movement.", "⌒"),
    ExerciseVariation("Hanging Knee Raise", Exercise.LEG_RAISE, "leg-raise", "Core & Hips", 2, "Minimize swinging; use a secure bar.", "⌃"),
    ExerciseVariation("Hanging Leg Raise", Exercise.LEG_RAISE, "leg-raise", "Core & Hips", 6, "Progress only with controlled trunk position.", "⌃"),
    ExerciseVariation("Lying Leg Raise", Exercise.LEG_RAISE, "leg-raise", "Core & Hips", 1, "Keep the lower back controlled.", "⌃"),
    ExerciseVariation("Sit-up", Exercise.SIT_UP, "sit-up", "Core & Hips", 0, "Use controlled trunk flexion, not momentum.", "↻"),
    ExerciseVariation("Crunch", Exercise.SIT_UP, "sit-up", "Core & Hips", 0, "Short controlled trunk range; avoid pulling the neck.", "↻"),
    ExerciseVariation("Bicycle Crunch", Exercise.SIT_UP, "sit-up", "Core & Hips", 2, "Rotate the trunk under control.", "↻"),
    ExerciseVariation("Knee Extension", Exercise.KNEE_EXTENSION, "knee-extension", "Legs", 2, "Controlled knee extension; use safe resistance.", "↕"),
    ExerciseVariation("Hamstring Curl", Exercise.HAMSTRING_CURL, "hamstring-curl", "Legs", 2, "Keep hips steady and avoid jerking.", "↕")
)

private fun baseExerciseForProfile(profileId: String): Exercise = when (profileId) {
    "push" -> Exercise.PUSH_UP
    "pull" -> Exercise.PULL_UP
    "dip" -> Exercise.DIP
    "row" -> Exercise.ROW
    "curl" -> Exercise.BICEP_CURL
    "overhead-press" -> Exercise.SHOULDER_PRESS
    "triceps-extension" -> Exercise.TRICEPS_EXTENSION
    "squat" -> Exercise.SQUAT
    "lunge" -> Exercise.LUNGE
    "step-up" -> Exercise.STEP_UP
    "knee-extension" -> Exercise.KNEE_EXTENSION
    "hamstring-curl" -> Exercise.HAMSTRING_CURL
    "hip-hinge" -> Exercise.HIP_HINGE
    "glute-bridge" -> Exercise.GLUTE_BRIDGE
    "leg-raise" -> Exercise.LEG_RAISE
    "sit-up" -> Exercise.SIT_UP
    "calf-raise" -> Exercise.CALF_RAISE
    "shoulder-raise" -> Exercise.SHOULDER_RAISE
    "wrist-curl" -> Exercise.WRIST_CURL
    else -> Exercise.NECK_MOBILITY
}

private fun loadCustomExercises(prefs: SharedPreferences): List<ExerciseVariation> = runCatching {
    val json = org.json.JSONArray(prefs.getString("items", "[]"))
    (0 until json.length()).mapNotNull { index ->
        val item = json.getJSONObject(index)
        val name = item.optString("name").trim()
        val profile = item.optString("profile", "push")
        if (name.isBlank()) null else ExerciseVariation(name, baseExerciseForProfile(profile), profile, "Custom", 0,
            "Custom exercise · ROM profile: ${RomProfileCatalog.get(profile).displayName}", "✧", true)
    }
}.getOrDefault(emptyList())

private fun saveCustomExercises(prefs: SharedPreferences, exercises: List<ExerciseVariation>) {
    val json = org.json.JSONArray()
    exercises.forEach { item -> json.put(org.json.JSONObject().put("name", item.name).put("profile", item.romProfile)) }
    prefs.edit().putString("items", json.toString()).apply()
}

@Composable
fun MainScreen() {
    var selected by remember { mutableIntStateOf(0) }
    var activeExercise by remember { mutableStateOf<Exercise?>(null) }
    var activeRomProfile by remember { mutableStateOf("push") }
    val workoutViewModel: WorkoutViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    if (activeExercise != null) {
        CameraWorkoutScreen(exercise = activeExercise!!, romProfileId = activeRomProfile, viewModel = workoutViewModel, onBack = { activeExercise = null })
        return
    }
    val tabs = listOf("Home", "Workout", "Ranks", "Progress", "Profile")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, title ->
                NavigationBarItem(selected = selected == i, onClick = { selected = i },
                    icon = { Text(listOf("⌂", "✦", "◈", "↗", "◉")[i], fontSize = 18.sp) }, label = { Text(title) })
            }
        }
    }) { pad ->
        when (selected) {
            0 -> HomeScreen(Modifier.padding(pad))
            1 -> WorkoutScreen(Modifier.padding(pad)) { exercise, profile -> workoutViewModel.selectExercise(exercise); activeRomProfile = profile; activeExercise = exercise }
            2 -> RanksScreen(Modifier.padding(pad))
            3 -> ProgressScreen(Modifier.padding(pad))
            else -> ProfileScreen(Modifier.padding(pad))
        }
    }
}

@Composable
private fun HomeScreen(m: Modifier) {
    val vm: WorkoutViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val push by vm.pushUpPr.collectAsState(initial = 0)
    val pull by vm.pullUpPr.collectAsState(initial = 0)
    val squat by vm.squatPr.collectAsState(initial = 0)
    val dip by vm.dipPr.collectAsState(initial = 0)
    val workouts by vm.history.collectAsState(initial = emptyList())
    val totals = RepTotals(push ?: 0, pull ?: 0, squat ?: 0)
    val rank = RepRankCalculator.overall(totals)
    val next = RepRank.entries.getOrNull(rank.ordinal + 1)
    val currentTarget = RepRequirements.minimum(Exercise.PUSH_UP, rank)
    val nextTarget = next?.let { RepRequirements.minimum(Exercise.PUSH_UP, it) } ?: currentTarget
    val ratio = if (nextTarget <= currentTarget) 1f else ((push ?: 0) - currentTarget).toFloat().div((nextTarget - currentTarget).coerceAtLeast(1)).coerceIn(0f, 1f)
    LazyColumn(m.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                RankEmblem()
                Column(Modifier.weight(1f)) {
                    Text("CULTIVATION RECORD", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(rank.label, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Realm ${rank.ordinal + 1} of 30 · ${workouts.size} sessions", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("YOUR CULTIVATION PATH", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text(rank.description, style = MaterialTheme.typography.bodyMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Current realm", style = MaterialTheme.typography.bodySmall)
                        Text(if (next == null) "Peak realm" else "Next: ${next.label}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    }
                    LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape), strokeCap = StrokeCap.Round)
                    Text(if (next == null) "Maximum realm reached" else "Push-up PR progress: ${push ?: 0} / $nextTarget", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("TRAINING RECORD", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item { Text("ALL EXERCISE RECORDS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            val allPrs by vm.allPrs.collectAsState(initial = emptyMap())
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Exercise.entries.toList().chunked(2).forEach { rowExercises ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowExercises.forEach { exercise ->
                            val title = exercise.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
                            StatCard(title, allPrs[exercise] ?: 0, "Personal record", "✦", Modifier.weight(1f))
                        }
                        if (rowExercises.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SKILL CULTIVATION", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Text("30 skill realms · holds, balance & control", style = MaterialTheme.typography.bodyMedium)
                        Text("Explore handstands, L-sits, levers and muscle-up progressions.", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("✧", fontSize = 30.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item { Text("RECENT ACTIVITY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (workouts.isEmpty()) item { Text("No sessions recorded yet. Start a workout to begin your record.", style = MaterialTheme.typography.bodyMedium) }
        items(workouts.take(3)) { w ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("◷", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${w.totalReps} verified reps", fontWeight = FontWeight.SemiBold)
                    Text(java.text.DateFormat.getDateTimeInstance().format(java.util.Date(w.startedAt)), style = MaterialTheme.typography.bodySmall)
                }
            } }
        }
    }
}

@Composable
private fun RankEmblem() {
    Box(Modifier.size(76.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(5.dp)) {
            drawCircle(color = androidx.compose.ui.graphics.Color(0xFFB68D45), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx()))
            drawCircle(color = androidx.compose.ui.graphics.Color(0xFFB68D45), radius = size.minDimension * .30f, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()))
        }
        Text("道", fontSize = 29.sp, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatCard(title: String, value: Int, note: String, symbol: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(symbol, color = MaterialTheme.colorScheme.primary, fontSize = 22.sp)
            }
            Text(value.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun WorkoutScreen(m: Modifier, onStart: (Exercise, String) -> Unit) {
    val context = LocalContext.current
    val customPrefs = remember(context) { context.getSharedPreferences("custom_exercises", android.content.Context.MODE_PRIVATE) }
    var customVariations by remember { mutableStateOf(loadCustomExercises(customPrefs)) }
    var showAddCustom by remember { mutableStateOf(false) }
    var customName by remember { mutableStateOf("") }
    var selectedProfile by remember { mutableStateOf("push") }
    var profileMenuExpanded by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("All") }
    val vm: WorkoutViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val push by vm.pushUpPr.collectAsState(initial = 0)
    val pull by vm.pullUpPr.collectAsState(initial = 0)
    val squat by vm.squatPr.collectAsState(initial = 0)
    val rank = RepRankCalculator.overall(RepTotals(push ?: 0, pull ?: 0, squat ?: 0))
    val allVariations = variations + customVariations
    val filtered = allVariations.filter { filter == "All" || it.group == filter }
    Column(m.fillMaxSize().padding(horizontal = 14.dp)) {
        Text("Training Hall", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 16.dp))
        Text("Variations unlock as your cultivation realm rises. Add custom movements without an app update.", style = MaterialTheme.typography.bodyMedium)
        OutlinedButton(onClick = { customName = ""; selectedProfile = "push"; showAddCustom = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Custom Exercise") }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 10.dp).horizontalScroll(rememberScrollState())) {
            listOf("All", "Push", "Pull", "Legs", "Arms", "Shoulders", "Core & Hips", "Custom").forEach { item ->
                FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item) })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(filtered) { v ->
                val unlocked = rank.ordinal >= v.unlockRank
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (unlocked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (unlocked) v.symbol else "🔒", fontSize = 25.sp, modifier = Modifier.padding(end = 12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(v.detail, style = MaterialTheme.typography.bodySmall)
                            Text(if (v.custom) "CUSTOM · ${RomProfileCatalog.get(v.romProfile).displayName}" else if (unlocked) "UNLOCKED · ${v.base.name.replace('_', ' ')}" else "Unlock at ${RepRank.entries[v.unlockRank].label}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        if (unlocked || v.custom) TextButton(onClick = { onStart(v.base, v.romProfile) }) { Text("Train") }
                    }
                }
            }
        }
    }
    if (showAddCustom) {
        AlertDialog(
            onDismissRequest = { showAddCustom = false },
            title = { Text("Add Custom Exercise") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = customName, onValueChange = { customName = it.take(50) }, label = { Text("Exercise name") }, singleLine = true)
                    Box {
                        OutlinedButton(onClick = { profileMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(RomProfileCatalog.get(selectedProfile).displayName)
                        }
                        DropdownMenu(expanded = profileMenuExpanded, onDismissRequest = { profileMenuExpanded = false }) {
                            RomProfileCatalog.profiles.forEach { profile ->
                                DropdownMenuItem(text = { Text(profile.displayName) }, onClick = { selectedProfile = profile.id; profileMenuExpanded = false })
                            }
                        }
                    }
                    Text("Choose the closest movement pattern. ROM accuracy depends on camera angle and visible landmarks.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = customName.trim()
                    if (clean.isNotBlank() && allVariations.none { it.name.equals(clean, ignoreCase = true) }) {
                        val item = ExerciseVariation(clean, baseExerciseForProfile(selectedProfile), selectedProfile, "Custom", 0,
                            "Custom exercise · ROM profile: ${RomProfileCatalog.get(selectedProfile).displayName}", "✧", true)
                        customVariations = customVariations + item
                        saveCustomExercises(customPrefs, customVariations)
                        filter = "Custom"
                        showAddCustom = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddCustom = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun RanksScreen(m: Modifier) {
    var info by remember { mutableStateOf<RankInfo?>(null) }
    var path by remember { mutableStateOf("Rep Rank") }
    Column(m.padding(12.dp)) {
        Text("Cultivation Realms", style = MaterialTheme.typography.headlineMedium)
        Text("Thirty realms. Four breakthroughs within each realm.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = path == "Rep Rank", onClick = { path = "Rep Rank" }, label = { Text("Body Realm · 30") })
            FilterChip(selected = path == "Skill Rank", onClick = { path = "Skill Rank" }, label = { Text("Skill Realm · 30") })
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            val ranks = if (path == "Rep Rank") RepRank.entries.map { Triple(it.label, it.description, it.ordinal) } else SkillRank.entries.map { Triple(it.label, it.description, it.ordinal) }
            items(ranks) { (label, description, index) ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { info = RankInfo(label, description) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("◈", color = MaterialTheme.colorScheme.primary, fontSize = 22.sp, modifier = Modifier.padding(end = 10.dp))
                            Column(Modifier.weight(1f)) { Text("Realm ${index + 1} · $label", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(description, style = MaterialTheme.typography.bodySmall) }
                        }
                        Text(if (path == "Rep Rank") repRequirementSummary(index) else "Progress through controlled holds, balance, strength and skill-specific challenges.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(5.dp))
                        subRanks.forEachIndexed { tierIndex, pair ->
                            Text("${tierIndex + 1}. ${pair.first}  ›", color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.fillMaxWidth().clickable { info = RankInfo("$label — ${pair.first}", pair.second + if (path == "Rep Rank") " Targets: ${repRequirementSummary(index)}" else " Complete the challenge with control and appropriate support.", pair.first) }.padding(vertical = 5.dp))
                        }
                    }
                }
            }
        }
    }
    info?.let { selected ->
        AlertDialog(onDismissRequest = { info = null }, title = { Text(selected.title) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(selected.description); if (selected.tier != null) Text("Breakthrough: ${selected.tier}"); Text("Progression guide only. Use clean form, adequate rest, and safe exercise progressions.") } },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Close") } })
    }
}

private fun repRequirementSummary(index: Int): String {
    val rank = RepRank.entries[index]
    return "Lifetime PR targets: ${RepRequirements.minimum(Exercise.PUSH_UP, rank)} push-ups · ${RepRequirements.minimum(Exercise.PULL_UP, rank)} pull-ups · ${RepRequirements.minimum(Exercise.SQUAT, rank)} squats · ${RepRequirements.minimum(Exercise.DIP, rank)} dips"
}

@Composable
private fun ProgressScreen(m: Modifier) {
    val vm: WorkoutViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val workouts by vm.history.collectAsState(initial = emptyList())
    val push by vm.pushUpPr.collectAsState(initial = 0)
    val pull by vm.pullUpPr.collectAsState(initial = 0)
    val squat by vm.squatPr.collectAsState(initial = 0)
    val allPrs by vm.allPrs.collectAsState(initial = emptyMap())
    Column(m.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Progress Record", style = MaterialTheme.typography.headlineMedium)
        Text("Personal records · verified workout history")
        Exercise.entries.forEach { exercise ->
            val title = exercise.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
            StatCard(title, allPrs[exercise] ?: 0, "Personal record", "✦", Modifier.fillMaxWidth())
        }
        Text("Sessions: ${workouts.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (workouts.isEmpty()) Text("Complete a camera workout to start your history.")
        workouts.take(20).forEach { workout ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text("${workout.totalReps} verified reps", fontWeight = FontWeight.SemiBold); Text("Started: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(workout.startedAt))}") } }
        }
    }
}

@Composable
private fun ProfileScreen(m: Modifier) = Column(m.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("Cultivator Profile", style = MaterialTheme.typography.headlineMedium)
    Text("Training mode: camera-based movement analysis")
    Text("Minimum Android version: Android 10 (API 29)")
    Text("Tip: place the phone far enough away to keep your full body in frame. Side-on positioning is recommended for rep analysis.")
}

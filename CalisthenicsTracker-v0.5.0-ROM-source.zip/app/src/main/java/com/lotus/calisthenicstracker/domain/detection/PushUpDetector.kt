package com.lotus.calisthenicstracker.domain.detection

/** Uses the shared profile-based ROM engine so thresholds are maintained centrally. */
class PushUpDetector : ExerciseDetector {
    private val delegate = ProfileRomDetector(RomProfileCatalog.get("push"))
    override fun phase(points: Map<String, Point2D>) = delegate.phase(points)
}

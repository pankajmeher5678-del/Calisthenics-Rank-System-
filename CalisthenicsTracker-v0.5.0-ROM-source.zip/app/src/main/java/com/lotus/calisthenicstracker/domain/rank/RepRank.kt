package com.lotus.calisthenicstracker.domain.rank

enum class Exercise {
    PUSH_UP, PULL_UP, SQUAT, DIP, ROW, BICEP_CURL, SHOULDER_PRESS, TRICEPS_EXTENSION,
    HIP_HINGE, GLUTE_BRIDGE, LEG_RAISE, SIT_UP, CALF_RAISE, SHOULDER_RAISE,
    KNEE_EXTENSION, HAMSTRING_CURL, LUNGE, STEP_UP, WRIST_CURL, NECK_MOBILITY
}

enum class RepRank(val label: String, val description: String) {
    QI_CONDENSATION("Qi Condensation", "Begin your path by building disciplined movement and reliable foundations."),
    FOUNDATION_ESTABLISHMENT("Foundation Establishment", "Your foundation grows stable through controlled, repeatable training."),
    MERIDIAN_OPENING("Meridian Opening", "Build stronger movement patterns and improve coordination."),
    CORE_FORMATION("Core Formation", "Your strength begins to consolidate into consistent performance."),
    GOLDEN_CORE("Golden Core", "Develop dependable power while keeping technique precise."),
    NASCENT_SOUL("Nascent Soul", "Your training becomes more resilient across multiple sessions."),
    SOUL_AWAKENING("Soul Awakening", "Refine control, stamina, and awareness of each repetition."),
    SPIRIT_SEVERING("Spirit Severing", "Demonstrate disciplined form under greater training demands."),
    VOID_REFINEMENT("Void Refinement", "Your foundation supports advanced bodyweight challenges."),
    BODY_INTEGRATION("Body Integration", "Strength and control begin to work as one."),
    DAO_SEEKING("Dao Seeking", "Pursue clean technique and patient progression."),
    DAO_FOUNDATION("Dao Foundation", "Build a broad base across pushing, pulling, and legs."),
    HEAVENLY_CORE("Heavenly Core", "Show consistency with increasingly demanding standards."),
    NASCENT_SPIRIT("Nascent Spirit", "Your movement quality remains steady as volume increases."),
    SOUL_TEMPERING("Soul Tempering", "Refine strength without sacrificing control."),
    VOID_WALKING("Void Walking", "Demonstrate precise and repeatable execution."),
    STAR_ASCENDANT("Star Ascendant", "Your practice reaches an advanced level of consistency."),
    HEAVENLY_VESSEL("Heavenly Vessel", "A strong all-round foundation supports difficult variations."),
    LAW_COMPREHENSION("Law Comprehension", "Strength, control, and stamina are becoming well integrated."),
    IMMORTAL_FOUNDATION("Immortal Foundation", "Maintain quality across challenging training sessions."),
    EARTH_IMMORTAL("Earth Immortal", "Show advanced discipline across core movement patterns."),
    HEAVEN_IMMORTAL("Heaven Immortal", "Your performance reflects long-term consistency."),
    GOLDEN_IMMORTAL("Golden Immortal", "Advanced strength is paired with careful technique."),
    IMMORTAL_MONARCH("Immortal Monarch", "A demanding level requiring patience and years of practice."),
    DAO_LORD("Dao Lord", "Maintain exceptional bodyweight strength and movement control."),
    DAO_SOVEREIGN("Dao Sovereign", "An elite tier of well-rounded and disciplined performance."),
    TRIBULATION_TRANSCENDER("Tribulation Transcender", "Show mastery through consistency, not rushed progression."),
    GREAT_ASCENDANT("Great Ascendant", "Approach the summit with exceptional control and capacity."),
    ETERNAL_VENERABLE("Eternal Venerable", "A legendary tier in this fictional cultivation ladder."),
    SUPREME_DAO_ANCESTOR("Supreme Dao Ancestor", "The highest title in this fictional progression system.")
}

/** Rep thresholds are lifetime personal-record targets; the rank is not a judgment of daily performance. */
object RepRequirements {
    fun minimum(exercise: Exercise, rank: RepRank): Int {
        val level = rank.ordinal
        return when (exercise) {
            Exercise.PUSH_UP -> level * 15
            Exercise.PULL_UP -> if (level == 0) 0 else 1 + (level - 1) * 2
            Exercise.SQUAT -> level * 30
            Exercise.DIP -> level * 5
            Exercise.ROW -> if (level == 0) 0 else level * 3
            Exercise.BICEP_CURL, Exercise.TRICEPS_EXTENSION, Exercise.SHOULDER_RAISE -> level * 8
            Exercise.SHOULDER_PRESS -> level * 6
            Exercise.HIP_HINGE, Exercise.GLUTE_BRIDGE -> level * 15
            Exercise.LEG_RAISE, Exercise.SIT_UP -> level * 12
            Exercise.CALF_RAISE -> level * 25
            Exercise.KNEE_EXTENSION, Exercise.HAMSTRING_CURL, Exercise.LUNGE, Exercise.STEP_UP -> level * 12
            Exercise.WRIST_CURL, Exercise.NECK_MOBILITY -> level * 8
        }
    }
}

data class RepTotals(val pushUps: Int = 0, val pullUps: Int = 0, val squats: Int = 0)

object RepRankCalculator {
    fun rankForExercise(exercise: Exercise, reps: Int): RepRank =
        RepRank.entries.lastOrNull { reps >= RepRequirements.minimum(exercise, it) } ?: RepRank.QI_CONDENSATION

    /** Overall rank cannot exceed the weakest of the three core rep exercises. */
    fun overall(t: RepTotals): RepRank = RepRank.entries.lastOrNull { rank ->
        t.pushUps >= RepRequirements.minimum(Exercise.PUSH_UP, rank) &&
        t.pullUps >= RepRequirements.minimum(Exercise.PULL_UP, rank) &&
        t.squats >= RepRequirements.minimum(Exercise.SQUAT, rank)
    } ?: RepRank.QI_CONDENSATION
}

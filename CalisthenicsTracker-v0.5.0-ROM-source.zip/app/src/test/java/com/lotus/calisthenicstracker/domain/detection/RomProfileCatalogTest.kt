package com.lotus.calisthenicstracker.domain.detection

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RomProfileCatalogTest {
    @Test fun profileIdsAreUnique() {
        val ids = RomProfileCatalog.profiles.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun everyNamedCatalogExerciseUsesAnExistingProfile() {
        val ids = RomProfileCatalog.profiles.map { it.id }.toSet()
        assertTrue(RomProfileCatalog.exerciseToProfile.isNotEmpty())
        RomProfileCatalog.exerciseToProfile.values.forEach { assertTrue("Missing profile: $it", it in ids) }
    }

    @Test fun profileLookupFallsBackSafely() {
        assertEquals("push", RomProfileCatalog.get("unknown-profile").id)
    }
}

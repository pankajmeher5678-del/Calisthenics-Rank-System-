# Build and install Calisthenics Tracker using your phone

The APK is built by GitHub Actions on a cloud build machine; you do not need Android Studio on your phone.

## Recommended: one-time signing setup

Follow `SIGNING_SETUP.md` to configure the four GitHub Actions secrets. This is necessary for future APKs to update over the installed app reliably. Keep the signing key and passwords private.

## Build

1. Open the repository's **Actions** tab.
2. Select **Build Calisthenics Tracker APK** and run the workflow, or push a commit to `main`.
3. Wait for the workflow to finish and inspect the build log if it fails.
4. Download the release artifact `CalisthenicsTracker-v0.5.0-release-signed` when signing secrets are configured. Otherwise the workflow uploads a clearly labeled debug APK, which may not update over a differently signed installation.
5. Extract the artifact ZIP and install the APK.

The first installation using a new persistent key may require uninstalling an older APK that used a different signing certificate. That can remove local app data.

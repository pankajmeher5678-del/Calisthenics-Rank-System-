# One-time persistent APK signing setup

The APK update error occurs when Android sees a different signing certificate. A debug keystore created on a temporary GitHub runner is not stable across builds.

## Create your private key once

On a trusted computer or in Termux, run:

```sh
keytool -genkeypair -v -keystore calisthenics-release.jks -alias calisthenics -keyalg RSA -keysize 2048 -validity 10000
```

Choose strong passwords and keep a secure backup of `calisthenics-release.jks` and the passwords. Never commit the keystore to GitHub and never send the passwords to ChatGPT.

Create a single-line base64 value:

```sh
base64 calisthenics-release.jks | tr -d '\n'
```

## Add GitHub Actions repository secrets

In the repository, open **Settings → Secrets and variables → Actions → New repository secret** and create:

- `ANDROID_KEYSTORE_BASE64` — the base64 output above
- `ANDROID_KEYSTORE_PASSWORD` — the keystore password
- `ANDROID_KEY_ALIAS` — `calisthenics` (or the alias you chose)
- `ANDROID_KEY_PASSWORD` — the key password

After these four secrets exist, the workflow builds a release APK signed with this persistent key. Keep using the same key for every future update.

## Existing installations

An APK previously signed with a different temporary debug key cannot be updated in-place with a new key. The first persistent-signed installation may require uninstalling the old app, which can erase locally stored app data. After the persistent-signed version is installed, future releases using the same key can update it normally.
